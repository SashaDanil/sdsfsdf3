"""A08-3: CLI для ручного запуска бэкапа из cron."""
import click
from flask import Flask


def register_cli(app: Flask) -> None:
    @app.cli.command('backup-now')
    def backup_now():
        """Разовый бэкап SQLite в BACKUP_DIR (для cron)."""
        from .backup import run_backup
        res = run_backup()
        if not res['ok']:
            click.echo(f"FAIL: {res['error']}", err=True)
            raise SystemExit(1)
        click.echo(f"OK: {res['path']} ({res['size']} B)")

    @app.cli.command('backup-list')
    def backup_list():
        """Показать существующие бэкапы."""
        from .backup import BACKUP_DIR
        files = sorted(BACKUP_DIR.glob('backup-*'), reverse=True)
        if not files:
            click.echo('Бэкапов нет.')
            return
        for f in files:
            click.echo(f'{f.name}  {f.stat().st_size:>10} B')