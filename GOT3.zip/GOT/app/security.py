# app/security.py
import re
from functools import wraps
from flask import request, session, abort, redirect, url_for, flash
from .config import PWD_MIN_LEN, PWD_MIN_CLASSES, MAX_FAILED_ATTEMPTS
from .extensions import db
from .models import AuditLog

# Прочитаем список probe-префиксов из dev_config (если он есть рядом).
# В проде dev_config.py отсутствует — используем безопасный fallback.
try:
    from .dev_config import PROBES as _PROBE_PREFIXES
except ImportError:
    _PROBE_PREFIXES = ('pentest_', 'csrf_')


def pwd_ok(password: str) -> tuple[bool, str]:
    """Проверяет сложность пароля. Возвращает (успех, сообщение об ошибке)."""
    if len(password) < PWD_MIN_LEN:
        return False, f"Пароль должен содержать минимум {PWD_MIN_LEN} символов"

    classes = 0
    if re.search(r'[a-z]', password): classes += 1
    if re.search(r'[A-Z]', password): classes += 1
    if re.search(r'[0-9]', password): classes += 1
    if re.search(r'[^a-zA-Z0-9]', password): classes += 1

    if classes < PWD_MIN_CLASSES:
        return False, (f"Пароль должен содержать минимум {PWD_MIN_CLASSES} "
                       f"класса символов (строчные, прописные, цифры, спецсимволы)")

    return True, ""


def valid_email(email: str) -> bool:
    """Простая проверка формата email."""
    if not email:
        return False
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{1,}$'
    return bool(re.match(pattern, email))


def is_probe(username: str) -> bool:
    """Является ли пользователь тестовым (созданным автотестами/пентестом)."""
    if not username:
        return False
    return any(str(username).startswith(p) for p in _PROBE_PREFIXES)


def audit(action: str, target: str = None, extra: str = None) -> None:
    """Записывает действие в журнал аудита."""
    try:
        ip = request.remote_addr or '0.0.0.0'
        if request.headers.get('X-Forwarded-For'):
            ip = request.headers.get('X-Forwarded-For').split(',')[0].strip()

        log_entry = AuditLog(
            user_id=session.get('user_id'),
            username=session.get('username'),
            ip=ip,
            action=action,
            target=target,
            extra=extra,
        )
        db.session.add(log_entry)
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        print(f"[!] Ошибка записи в аудит: {e}")


def login_required(f):
    """Декоратор: требует авторизации."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('user_id'):
            flash('Пожалуйста, войдите в систему.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def admin_required(f):
    """Декоратор: требует прав администратора."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('user_id'):
            return redirect(url_for('login'))
        if not session.get('is_admin'):
            abort(403)
        return f(*args, **kwargs)
    return decorated_function


def no_store(f):
    """Декоратор: запрещает кэширование ответа."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        response = f(*args, **kwargs)
        resp_obj = response[0] if isinstance(response, tuple) else response
        if hasattr(resp_obj, 'headers'):
            resp_obj.headers['Cache-Control'] = (
                'no-store, no-cache, must-revalidate, max-age=0')
            resp_obj.headers['Pragma'] = 'no-cache'
            resp_obj.headers['Expires'] = '0'
        return response
    return decorated_function


def validate_csrf():
    """
    Глобальная проверка CSRF-токена для всех POST-запросов.
    Вызывается через app.before_request.
    """
    if request.method in ['POST', 'PUT', 'DELETE', 'PATCH']:
        if request.is_json:
            audit('csrf_fail', extra='JSON content type rejected')
            abort(400)

        token = request.form.get('_csrf_token')
        session_token = session.get('_csrf')

        if not token or not session_token or token != session_token:
            audit('csrf_fail', extra='Missing or invalid CSRF token')
            abort(400)


def generate_csrf():
    """Генерирует CSRF-токен и сохраняет его в сессии."""
    import secrets
    if '_csrf' not in session:
        session['_csrf'] = secrets.token_hex(32)
    return session['_csrf']