# app/extensions.py — расширения Flask и низкоуровневые хелперы
"""
Содержит:
  * db                    — единый экземпляр Flask-SQLAlchemy;
  * lock                  — глобальный RLock для критических секций;
  * commit()              — безопасный commit с rollback при ошибке;
  * immediate_transaction — контекст-менеджер транзакции (для SQLite
                            выдаёт BEGIN IMMEDIATE, чтобы избежать
                            гонок "read-modify-write" при параллельных
                            запросах);
  * init_app(app)         — инициализация расширений из create_app().
"""
from __future__ import annotations

import threading
from contextlib import contextmanager

from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import text

# ---------------------------------------------------------------------------
# Единственный экземпляр SQLAlchemy на всё приложение.
# Импортируется везде: from app.extensions import db
# ---------------------------------------------------------------------------
db = SQLAlchemy()


# ---------------------------------------------------------------------------
# Глобальный RLock.
#
# Используется для сериализации критических секций в рамках одного
# процесса (waitress запускается с threads=8, но в одном процессе):
#   * списание / возврат остатков при оформлении заказа;
#   * смена статуса заказа админом;
#   * генерация/отзыв цифровых паспортов;
#   * очистка тестовых пользователей.
#
# Пример:
#     from app.extensions import lock
#     with lock:
#         product.stock_m -= qty
#         db.session.commit()
# ---------------------------------------------------------------------------
lock = threading.RLock()


# ---------------------------------------------------------------------------
# Безопасный commit
# ---------------------------------------------------------------------------
def commit() -> None:
    """
    Зафиксировать текущую сессию.

    При любой ошибке — откат и проброс исключения дальше, чтобы
    транзакция не осталась «висячей» и БД не ушла в неконсистентное
    состояние.
    """
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        raise


# ---------------------------------------------------------------------------
# Транзакция с BEGIN IMMEDIATE (актуально для SQLite)
# ---------------------------------------------------------------------------
@contextmanager
def immediate_transaction():
    """
    Контекстный менеджер для транзакции записи.

    Что делает:
      * берёт глобальный RLock (защита внутри процесса);
      * для SQLite пытается выполнить `BEGIN IMMEDIATE` — это берёт
        write-lock на файл БД сразу и предотвращает гонку между
        параллельными read-modify-write операциями;
      * коммитит при успехе и делает rollback при исключении.

    Использование:
        with immediate_transaction():
            product.stock_m -= qty
            order.total = new_total

    Для не-SQLite СУБД работает как обычная транзакция.
    """
    with lock:
        session = db.session

        # Для SQLite — сразу берём write-lock.
        try:
            bind = session.get_bind()
        except Exception:
            bind = None

        is_sqlite = bind is not None and bind.dialect.name == "sqlite"
        if is_sqlite:
            try:
                session.execute(text("BEGIN IMMEDIATE"))
            except Exception:
                # Если сессия уже в транзакции (autobegin сработал раньше
                # из-за предыдущего SELECT/UPDATE) — молча продолжаем:
                # rollback/commit ниже всё равно закроют её корректно.
                pass

        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise


# ---------------------------------------------------------------------------
# Инициализация расширений
# ---------------------------------------------------------------------------
def init_app(app) -> None:
    """
    Подключить расширения к приложению.
    Вызывается из app/__init__.py: extensions.init_app(app).
    """
    db.init_app(app)


__all__ = [
    "db",
    "lock",
    "commit",
    "immediate_transaction",
    "init_app",
]