"""app/admin_health.py — нагрузочное тестирование БД из админки.

Регистрация:  init_admin_health(app)  вызывается из create_app().

Маршруты:
  GET  /admin/db-health                 — страница
  POST /admin/db-health/run             — запустить тест (JSON)
  POST /admin/db-health/clear-history   — очистить историю
  GET  /admin/db-health/export.csv      — выгрузка истории
"""
from __future__ import annotations

import csv
import io
import statistics
import time
from concurrent.futures import ThreadPoolExecutor
from functools import wraps

from flask import (Response, abort, jsonify, render_template, request,
                   session)
from sqlalchemy import text

from .extensions import commit, db
from .models import DBHealthRun, User


# Только фиксированные пресеты — произвольный SQL не принимаем.
QUERY_PRESETS = {
    'ping': ('SELECT 1', 'Ping (SELECT 1)'),
    'count_product': ('SELECT COUNT(*) FROM product', 'COUNT(*) товаров'),
    'recent_orders': (
        'SELECT id, number, total FROM "order" '
        'ORDER BY created_at DESC LIMIT 50',
        'Последние 50 заказов',
    ),
    'join_order_user': (
        'SELECT o.id, o.total, u.username '
        'FROM "order" o JOIN "user" u ON u.id = o.user_id '
        'ORDER BY o.created_at DESC LIMIT 100',
        'JOIN заказы + пользователи (100)',
    ),
    'product_scan': (
        'SELECT id, article, name, price_per_m FROM product',
        'Полный скан product',
    ),
}

MAX_ITERATIONS    = 5000
MAX_CONCURRENCY   = 32
WARMUP_PER_WORKER = 5
HISTORY_LIMIT     = 20


# ---------- helpers ----------

def _admin_required(fn):
    """403 для всех, кто не админ; 401 без логина."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        uid = session.get('user_id')
        if not uid:
            abort(401)
        u = db.session.get(User, uid)
        if not u or not u.is_admin:
            abort(403)
        return fn(*args, **kwargs)
    return wrapper


def _percentile(values, p):
    if not values:
        return 0.0
    values = sorted(values)
    k = (len(values) - 1) * p
    f = int(k)
    c = min(f + 1, len(values) - 1)
    if f == c:
        return values[f]
    return values[f] + (values[c] - values[f]) * (k - f)


def _worker(engine, sql, iterations):
    """Один поток: свой connection из пула, WARMUP + замер."""
    latencies = []
    with engine.connect() as conn:
        for _ in range(WARMUP_PER_WORKER):
            conn.execute(text(sql))
        for _ in range(iterations):
            t0 = time.perf_counter()
            conn.execute(text(sql))
            latencies.append((time.perf_counter() - t0) * 1000.0)
    return latencies


def _run_benchmark(engine, sql, iterations, concurrency):
    per_worker = max(1, iterations // concurrency)
    start = time.perf_counter()
    with ThreadPoolExecutor(max_workers=concurrency) as pool:
        chunks = list(pool.map(
            lambda _: _worker(engine, sql, per_worker),
            range(concurrency),
        ))
    elapsed = time.perf_counter() - start
    latencies = [x for ch in chunks for x in ch]
    if not latencies:
        return None
    return {
        'iterations': len(latencies),
        'per_worker': per_worker,
        'concurrency': concurrency,
        'elapsed_s': round(elapsed, 3),
        'avg_ms':   round(statistics.mean(latencies), 2),
        'p50_ms':   round(_percentile(latencies, 0.50), 2),
        'p95_ms':   round(_percentile(latencies, 0.95), 2),
        'p99_ms':   round(_percentile(latencies, 0.99), 2),
        'min_ms':   round(min(latencies), 2),
        'max_ms':   round(max(latencies), 2),
        'throughput': round(len(latencies) / elapsed, 2) if elapsed else 0.0,
    }


def _db_info():
    url = db.engine.url
    dialect = url.get_backend_name()
    info = {
        'dialect':  dialect,
        'driver':   url.get_driver_name(),
        'database': url.database or '—',
        'host':     url.host or '—',
        'username': url.username or '—',
    }
    try:
        with db.engine.connect() as conn:
            if dialect == 'postgresql':
                info['version'] = str(conn.execute(text('SELECT version()')).scalar())
                info['db_size'] = str(conn.execute(
                    text('SELECT pg_size_pretty(pg_database_size(current_database()))')
                ).scalar())
            elif dialect == 'sqlite':
                info['version'] = 'SQLite ' + str(
                    conn.execute(text('SELECT sqlite_version()')).scalar())
                info['db_size'] = '—'
            else:
                info['version'] = '—'
                info['db_size'] = '—'
    except Exception as e:  # noqa: BLE001
        info['version'] = f'error: {e}'
        info['db_size'] = '—'
    try:
        info['pool_size'] = db.engine.pool.size()
    except Exception:  # noqa: BLE001
        info['pool_size'] = '—'
    return info


def _table_counts():
    """Строк в каждой таблице из metadata."""
    out = []
    for name in sorted(db.metadata.tables):
        try:
            n = db.session.execute(
                text(f'SELECT COUNT(*) FROM "{name}"')
            ).scalar() or 0
            out.append((name, int(n)))
        except Exception:  # noqa: BLE001
            out.append((name, '—'))
    return out


# ---------- routes ----------

def init_admin_health(app):
    """Регистрирует все маршруты на приложении. Вызывать из create_app()."""

    @app.route('/admin/db-health', endpoint='admin_db_health')
    @_admin_required
    def admin_db_health():
        history = (DBHealthRun.query
                   .order_by(DBHealthRun.ts.desc())
                   .limit(HISTORY_LIMIT)
                   .all())
        return render_template(
            'admin_db_health.html',
            info=_db_info(),
            table_counts=_table_counts(),
            presets=QUERY_PRESETS,
            history=history,
            max_iterations=MAX_ITERATIONS,
            max_concurrency=MAX_CONCURRENCY,
        )

    @app.route('/admin/db-health/run', methods=['POST'],
               endpoint='admin_db_health_run')
    @_admin_required
    def admin_db_health_run():
        preset = (request.form.get('preset') or '').strip()
        if preset not in QUERY_PRESETS:
            return jsonify({'error': 'Неизвестный пресет'}), 400

        try:
            iterations  = int(request.form.get('iterations', 100))
            concurrency = int(request.form.get('concurrency', 1))
        except (TypeError, ValueError):
            return jsonify({'error': 'iterations/concurrency — целые'}), 400

        iterations  = max(1, min(iterations,  MAX_ITERATIONS))
        concurrency = max(1, min(concurrency, MAX_CONCURRENCY))
        sql, label  = QUERY_PRESETS[preset]

        try:
            result = _run_benchmark(db.engine, sql, iterations, concurrency)
        except Exception as e:  # noqa: BLE001
            return jsonify({
                'error': f'Тест упал: {type(e).__name__}: {e}'
            }), 500
        if result is None:
            return jsonify({'error': 'Не получили ни одного замера'}), 500

        result['preset'] = preset
        result['preset_label'] = label

        try:
            db.session.add(DBHealthRun(
                username=session.get('username'),
                preset=preset,
                iterations=result['iterations'],
                concurrency=concurrency,
                elapsed_s=result['elapsed_s'],
                avg_ms=result['avg_ms'],
                p50_ms=result['p50_ms'],
                p95_ms=result['p95_ms'],
                p99_ms=result['p99_ms'],
                min_ms=result['min_ms'],
                max_ms=result['max_ms'],
                throughput=result['throughput'],
            ))
            commit()
        except Exception:  # noqa: BLE001
            db.session.rollback()

        return jsonify(result)

    @app.route('/admin/db-health/clear-history', methods=['POST'],
               endpoint='admin_db_health_clear_history')
    @_admin_required
    def admin_db_health_clear_history():
        DBHealthRun.query.delete()
        commit()
        return jsonify({'ok': True})

    @app.route('/admin/db-health/export.csv',
               endpoint='admin_db_health_export_csv')
    @_admin_required
    def admin_db_health_export_csv():
        buf = io.StringIO()
        w = csv.writer(buf, delimiter=';')
        w.writerow(['ts', 'username', 'preset', 'iterations', 'concurrency',
                    'elapsed_s', 'avg_ms', 'p50_ms', 'p95_ms', 'p99_ms',
                    'min_ms', 'max_ms', 'throughput'])
        for r in DBHealthRun.query.order_by(DBHealthRun.ts.desc()).all():
            w.writerow([
                r.ts.strftime('%Y-%m-%d %H:%M:%S') if r.ts else '',
                r.username or '', r.preset, r.iterations, r.concurrency,
                r.elapsed_s, r.avg_ms, r.p50_ms, r.p95_ms, r.p99_ms,
                r.min_ms, r.max_ms, r.throughput,
            ])
        data = '\ufeff' + buf.getvalue()
        return Response(
            data,
            mimetype='text/csv; charset=utf-8',
            headers={
                'Content-Disposition':
                    'attachment; filename="db_health_history.csv"'
            },
        )

    # Подтверждение в консоли — сразу видно, что регистрация прошла.
    print('[OK] admin_health: маршруты /admin/db-health* зарегистрированы')