"""Маршруты авторизации, регистрации и профиля."""
from datetime import datetime, timedelta

from flask import (flash, redirect, render_template, request, session,
                   url_for)
from sqlalchemy import func, select
from werkzeug.security import check_password_hash, generate_password_hash

from ..extensions import commit, db
from ..models import AuditLog, LoginAttempt, RegisterAttempt, User
from ..security import login_required, pwd_ok, valid_email


def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip()

        # 1. Проверка на дубликат
        if db.session.scalar(select(User).where(User.username == username)):
            flash('Этот логин уже занят.', 'danger')
            return render_template('register.html')

        # 2. Проверка сложности пароля
        is_ok, msg = pwd_ok(password)
        if not is_ok:
            flash(msg, 'danger')
            return render_template('register.html')

        # 3. Проверка email (если указан)
        if email and not valid_email(email):
            flash('Некорректный формат email.', 'danger')
            return render_template('register.html')

        # 4. Создание пользователя.
        #    is_probe — @property на модели, вычисляется из username.
        #    Передавать его в конструктор нельзя (нет сеттера → AttributeError).
        u = User(
            username=username,
            password_hash=generate_password_hash(password, method='scrypt'),
            full_name=full_name,
            email=email,
        )
        db.session.add(u)
        commit()

        # 5. Аудит и попытки регистрации
        db.session.add(RegisterAttempt(ip=request.remote_addr))
        db.session.add(AuditLog(
            user_id=u.id, username=username, ip=request.remote_addr,
            action='register', target=username
        ))
        commit()

        flash('Регистрация успешна. Теперь вы можете войти.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')


def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        # 1. Проверка блокировки (защита от брутфорса)
        cutoff = datetime.now() - timedelta(minutes=15)
        fails = db.session.scalar(
            select(func.count()).select_from(LoginAttempt).where(
                LoginAttempt.username == username,
                LoginAttempt.success == False,
                LoginAttempt.created_at >= cutoff
            )
        )
        if fails >= 5:
            flash('Слишком много попыток входа. Попробуйте позже.', 'danger')
            return render_template('login.html')

        # 2. Поиск пользователя и проверка пароля
        u = db.session.scalar(select(User).where(User.username == username))
        if not u or not check_password_hash(u.password_hash, password):
            db.session.add(LoginAttempt(username=username,
                                        ip=request.remote_addr,
                                        success=False))
            commit()
            flash('Неверный логин или пароль.', 'danger')
            return render_template('login.html')

        # 3. Проверка временного пароля (если истёк)
        if (u.must_change_password and u.temp_password_expires_at
                and u.temp_password_expires_at < datetime.now()):
            flash('Срок действия временного пароля истёк.', 'danger')
            return render_template('login.html')

        # 4. Успешный вход
        db.session.add(LoginAttempt(username=username,
                                    ip=request.remote_addr, success=True))
        db.session.add(AuditLog(
            user_id=u.id, username=u.username, ip=request.remote_addr,
            action='login', target=u.username
        ))
        commit()

        session['user_id'] = u.id
        session['username'] = u.username
        session['full_name'] = u.full_name
        session['is_admin'] = u.is_admin
        session['session_version'] = u.session_version

        if u.must_change_password:
            flash('Необходимо сменить временный пароль.', 'warning')
            return redirect(url_for('profile'))

        return redirect(url_for('index'))

    return render_template('login.html')


def logout():
    session.clear()
    flash('Вы вышли из системы.', 'info')
    return redirect(url_for('login'))


@login_required
def profile():
    u = db.session.get(User, session['user_id'])
    return render_template('profile.html', user=u)


@login_required
def change_password():
    if request.method == 'POST':
        u = db.session.get(User, session['user_id'])
        old_password = request.form.get('old_password', '')
        new_password = request.form.get('new_password', '')
        confirm_password = request.form.get('confirm_password', '')

        if not check_password_hash(u.password_hash, old_password):
            flash('Неверный старый пароль.', 'danger')
            return redirect(url_for('profile'))

        if new_password != confirm_password:
            flash('Пароли не совпадают.', 'danger')
            return redirect(url_for('profile'))

        is_ok, msg = pwd_ok(new_password)
        if not is_ok:
            flash(msg, 'danger')
            return redirect(url_for('profile'))

        u.password_hash = generate_password_hash(new_password, method='scrypt')
        u.must_change_password = False
        u.temp_password_expires_at = None
        u.session_version += 1
        session['session_version'] = u.session_version

        db.session.add(AuditLog(
            user_id=u.id, username=u.username, ip=request.remote_addr,
            action='change_password', target=u.username
        ))
        commit()

        flash('Пароль успешно изменён.', 'success')
        return redirect(url_for('profile'))

    return redirect(url_for('profile'))


def register_routes(app):
    """Регистрация маршрутов авторизации."""
    app.add_url_rule('/login', view_func=login, methods=['GET', 'POST'])
    app.add_url_rule('/register', view_func=register, methods=['GET', 'POST'])
    app.add_url_rule('/logout', view_func=logout, methods=['POST'])
    app.add_url_rule('/profile', view_func=profile, methods=['GET'])
    app.add_url_rule('/change_password', view_func=change_password,
                     methods=['POST'])