"""app/routes/__init__.py — регистрация всех маршрутов ИталКожДА.

Вызывается из app.__init__.create_app():
    from . import routes
    routes.init_app(app)

Соглашение в проекте: каждый модуль (admin, auth, cart, health,
orders, shop) экспортирует функцию register_routes(app).
На случай, если где-то назвали её init_app, — поддерживаем оба имени.
"""
from . import admin, auth, cart, health, orders, passports, shop

_MODULES = (admin, auth, cart, health, orders, passports, shop)


def init_app(app):
    """Зарегистрировать все маршруты на приложении."""
    for mod in _MODULES:
        fn = getattr(mod, 'register_routes', None) or getattr(mod, 'init_app', None)
        if fn is not None:
            fn(app)
    return app


# Псевдоним: если какой-то внешний код/тест вызывает
# routes.register_routes(app), всё продолжит работать.
register_routes = init_app