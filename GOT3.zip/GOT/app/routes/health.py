"""Служебные эндпоинты: /health и favicon."""
from datetime import datetime

from flask import Response, jsonify


def health():
    return jsonify(status='ok',
                   time=datetime.now().isoformat(timespec='seconds')), 200


def favicon():
    return Response(
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
        '<rect width="64" height="64" rx="12" fill="#0d6efd"/>'
        '<text x="32" y="42" font-size="32" text-anchor="middle" fill="#fff"'
        ' font-family="Arial">И</text></svg>',
        mimetype='image/svg+xml')


def register_routes(app):
    app.add_url_rule('/health',      view_func=health)
    app.add_url_rule('/favicon.ico', view_func=favicon)