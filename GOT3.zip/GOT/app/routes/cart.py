"""Корзина: просмотр, добавление/обновление/удаление, оформление."""
from datetime import datetime
from decimal import Decimal

from flask import flash, redirect, render_template, request, session, url_for
from sqlalchemy import delete
from sqlalchemy.exc import IntegrityError

from ..extensions import commit, db, immediate_transaction, lock
from ..models import CartItem, Order, OrderItem, Product, User
from ..security import audit, login_required, validate_csrf
from ..utils import _qty, build_cart, cart_set
from ..mail import notify_order_created


@login_required
def cart_view():
    return render_template('cart.html', cart=build_cart(session['user_id']))


def _cart_set_impl(pid, is_add):
    validate_csrf()
    qty = _qty(request.form.get('qty_m'))
    if qty is None or qty <= 0 or qty > 10**6:
        flash('Некорректное количество', 'danger')
        return redirect(url_for('cart_view'))
    uid = session['user_id']

    try:
        with immediate_transaction():
            p = db.session.get(Product, pid)
            if not p:
                flash('Товар не найден', 'danger')
                return redirect(url_for('index'))
            if is_add:
                ci = db.session.get(CartItem, (uid, pid))
                current = ci.qty_m if ci else Decimal('0')
                requested = qty
                qty = min(current + requested, p.stock_m)
                if current + requested > p.stock_m:
                    flash(f'На складе только {p.stock_m} м', 'warning')
            else:
                if qty > p.stock_m:
                    flash(f'На складе только {p.stock_m} м', 'warning')
                    qty = p.stock_m
            cart_set(uid, pid, qty)
    except IntegrityError:
        flash('Не удалось обновить корзину, попробуйте ещё раз', 'danger')
        return redirect(url_for('cart_view'))

    flash(f'Товар в корзине ({qty} м)', 'success')
    return redirect(url_for('cart_view'))


@login_required
def cart_add(pid):
    return _cart_set_impl(pid, is_add=True)


@login_required
def cart_update(pid):
    return _cart_set_impl(pid, is_add=False)


@login_required
def cart_remove(pid):
    validate_csrf()
    cart_set(session['user_id'], pid, Decimal('0'))
    commit()
    flash('Позиция удалена', 'info')
    return redirect(url_for('cart_view'))


@login_required
def cart_clear():
    validate_csrf()
    db.session.execute(
        delete(CartItem).where(CartItem.user_id == session['user_id']))
    commit()
    flash('Корзина очищена', 'info')
    return redirect(url_for('cart_view'))


@login_required
def cart_checkout():
    validate_csrf()
    uid = session['user_id']

    oid = None
    num = None
    total = None

    try:
        with immediate_transaction():
            c = build_cart(uid)
            if c.is_empty:
                flash('Корзина пуста', 'warning')
                return redirect(url_for('cart_view'))

            for it in c.lines:
                if it['qty'] > it['product'].stock_m:
                    flash(
                        f"«{it['product'].name}»: на складе только "
                        f"{it['product'].stock_m} м",
                        'danger',
                    )
                    return redirect(url_for('cart_view'))

            num = f"З-{datetime.now().strftime('%Y%m%d%H%M%S%f')[:-3]}"
            o = Order(
                number=num,
                user_id=uid,
                total=Decimal('0'),
                status='new',
            )
            db.session.add(o)
            db.session.flush()

            total = Decimal('0')
            for it in c.lines:
                p = it['product']
                lt = it['qty'] * p.price_per_m
                db.session.add(OrderItem(
                    order_id=o.id,
                    product_id=p.id,
                    qty_m=it['qty'],
                    price=p.price_per_m,
                    total=lt,
                ))
                total += lt
                p.stock_m -= it['qty']

            o.total = total
            oid = o.id

            db.session.execute(
                delete(CartItem).where(CartItem.user_id == uid)
            )

    except IntegrityError:
        flash(
            'Товар закончился или изменился остаток. Обновите корзину.',
            'danger',
        )
        return redirect(url_for('cart_view'))

    audit('order_create', num, f'total={total}')

    try:
        o = db.session.get(Order, oid)
        u = db.session.get(User, uid)
        if o and u:
            notify_order_created(o, u)
            commit()
    except Exception:
        pass

    flash(f'Заказ {num} оформлен на сумму {total:.2f} ₽', 'success')
    return redirect(url_for('order_detail', oid=oid))


def register_routes(app):
    app.add_url_rule('/cart', view_func=cart_view)
    app.add_url_rule('/cart/add/<int:pid>', view_func=cart_add,
                     methods=['POST'])
    app.add_url_rule('/cart/update/<int:pid>', view_func=cart_update,
                     methods=['POST'])
    app.add_url_rule('/cart/remove/<int:pid>', view_func=cart_remove,
                     methods=['POST'])
    app.add_url_rule('/cart/clear', view_func=cart_clear,
                     methods=['POST'])
    app.add_url_rule('/cart/checkout', view_func=cart_checkout,
                     methods=['POST'])