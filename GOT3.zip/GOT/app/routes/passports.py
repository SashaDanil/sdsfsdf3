"""Цифровые паспорта товаров: админка + публичная страница + QR."""
from __future__ import annotations

import uuid as uuidlib

import qrcode
import qrcode.image.svg
from flask import (Response, abort, flash, redirect, render_template,
                   request, session, url_for)
from sqlalchemy import select

from ..extensions import commit, db
from ..models import AuditLog, PassportEvent, Product, ProductPassport
from ..security import admin_required, no_store


@no_store
@admin_required
def admin_passports():
    passports = (
        db.session.scalars(
            select(ProductPassport)
            .join(Product, Product.id == ProductPassport.product_id)
            .order_by(ProductPassport.issued_at.desc())
        ).all()
    )
    issued_ids = [pp.product_id for pp in passports]

    without_q = select(Product).order_by(Product.article)
    if issued_ids:
        without_q = without_q.where(~Product.id.in_(issued_ids))
    without = db.session.scalars(without_q).all()

    return render_template(
        'admin_passports.html',
        passports=passports,
        without=without,
        total_products=db.session.scalar(select(db.func.count()).select_from(Product)) or 0,
    )


@admin_required
def admin_passport_generate(pid):
    p = db.session.get(Product, pid)
    if not p:
        abort(404)
    if p.passport:
        flash('У товара уже есть паспорт.', 'info')
        return redirect(url_for('admin_passports'))

    pp = ProductPassport(
        product_id=p.id,
        uuid=str(uuidlib.uuid4()),
        issued_by=session.get('user_id'),
    )
    db.session.add(pp)
    db.session.flush()

    db.session.add(PassportEvent(
        passport_id=pp.id,
        event_type='created',
        username=session.get('username'),
        metadata_=f'product={p.article}',
    ))
    db.session.add(AuditLog(
        user_id=session['user_id'],
        username=session.get('username') or '',
        ip=request.remote_addr or '',
        action='passport_create',
        target=p.article,
        extra=pp.uuid,
    ))
    commit()
    flash(f'Паспорт для «{p.article}» создан.', 'success')
    return redirect(url_for('admin_passports'))


@admin_required
def admin_passport_revoke(pid):
    p = db.session.get(Product, pid)
    if not p or not p.passport:
        abort(404)

    p.passport.revoked = not p.passport.revoked
    db.session.add(PassportEvent(
        passport_id=p.passport.id,
        event_type='revoked' if p.passport.revoked else 'restored',
        username=session.get('username'),
    ))
    db.session.add(AuditLog(
        user_id=session['user_id'],
        username=session.get('username') or '',
        ip=request.remote_addr or '',
        action='passport_revoke' if p.passport.revoked else 'passport_restore',
        target=p.article,
        extra=p.passport.uuid,
    ))
    commit()
    flash(
        f'Паспорт «{p.article}» '
        f'{"отозван" if p.passport.revoked else "восстановлен"}.',
        'warning' if p.passport.revoked else 'success',
    )
    return redirect(url_for('admin_passports'))


@admin_required
def admin_passport_delete(pid):
    p = db.session.get(Product, pid)
    if not p or not p.passport:
        abort(404)
    uuid_str = p.passport.uuid
    db.session.delete(p.passport)
    db.session.add(AuditLog(
        user_id=session['user_id'],
        username=session.get('username') or '',
        ip=request.remote_addr or '',
        action='passport_delete',
        target=p.article,
        extra=uuid_str,
    ))
    commit()
    flash('Паспорт удалён.', 'success')
    return redirect(url_for('admin_passports'))


@no_store
@admin_required
def admin_passport_qr(pid):
    p = db.session.get(Product, pid)
    if not p or not p.passport:
        abort(404)

    url = url_for('passport_public', uuid=p.passport.uuid, _external=True)
    img = qrcode.make(
        url,
        image_factory=qrcode.image.svg.SvgPathImage,
        box_size=10,
        border=2,
    )
    svg_data = img.to_string()
    if isinstance(svg_data, str):
        svg_data = svg_data.encode('utf-8')

    return Response(
        svg_data,
        mimetype='image/svg+xml',
        headers={
            'Cache-Control': 'no-store',
            'Content-Disposition': f'inline; filename="passport-{p.article}.svg"',
        },
    )


def passport_public(uuid):
    pp = db.session.scalar(
        select(ProductPassport).where(ProductPassport.uuid == uuid)
    )
    if not pp:
        abort(404)
    if pp.revoked:
        return render_template('passport_revoked.html', passport=pp), 410
    return render_template('passport_public.html', passport=pp)


def register_routes(app):
    app.add_url_rule('/admin/passports', view_func=admin_passports)
    app.add_url_rule(
        '/admin/passports/<int:pid>/generate',
        view_func=admin_passport_generate,
        methods=['POST'],
    )
    app.add_url_rule(
        '/admin/passports/<int:pid>/revoke',
        view_func=admin_passport_revoke,
        methods=['POST'],
    )
    app.add_url_rule(
        '/admin/passports/<int:pid>/delete',
        view_func=admin_passport_delete,
        methods=['POST'],
    )
    app.add_url_rule(
        '/admin/passports/<int:pid>/qr.svg',
        view_func=admin_passport_qr,
    )
    app.add_url_rule('/passport/<uuid>', view_func=passport_public)