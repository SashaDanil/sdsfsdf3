"""Админка: заказы, пользователи, статистика, журнал аудита."""
from collections import Counter
from datetime import datetime, timedelta
from decimal import Decimal

from flask import (abort, flash, redirect, render_template, request,
                   session, url_for)
from sqlalchemy import func, or_, select
from sqlalchemy.exc import IntegrityError

from ..config import RETURNABLE, STATUSES, TEMP_PASSWORD_TTL
from ..extensions import commit, db, immediate_transaction, lock
from ..models import AuditLog, Favorite, Order, OrderItem, Product, User
from ..security import (admin_required, audit, is_probe, no_store,
                        validate_csrf)
from ..utils import (_int, _qs, admins_count, purge_user, return_stock)


@admin_required
def admin_change_status(oid):
    validate_csrf()
    new = request.form.get('status', '')
    if new not in STATUSES:
        flash('Некорректный статус', 'danger')
        return redirect(url_for('admin_orders'))

    try:
        with immediate_transaction():
            o = db.session.get(Order, oid)
            if not o:
                abort(404)
            old = o.status
            if old == new:
                return redirect(url_for('admin_orders'))
            if old == 'cancelled' and new != 'cancelled':
                for it in o.items:
                    if not it.product:
                        flash(f'Товар id={it.product_id} не найден — статус не изменён.',
                              'danger')
                        return redirect(url_for('admin_orders'))
                    if it.product.stock_m < it.qty_m:
                        flash(f"Недостаточно «{it.product.name}» "
                              f"({it.product.stock_m} м < {it.qty_m} м)", 'danger')
                        return redirect(url_for('admin_orders'))
                for it in o.items:
                    it.product.stock_m = it.product.stock_m - it.qty_m
            elif new == 'cancelled':
                return_stock(o)
            o.status = new
            num = o.number
    except IntegrityError:
        flash('Не удалось изменить статус: конфликт данных', 'danger')
        return redirect(url_for('admin_orders'))

    audit('order_status', num, f'{old}->{new}')
    flash(f'Статус заказа {num}: {STATUSES[new]}', 'success')
    return redirect(url_for('admin_orders'))


@admin_required
def admin_orders():
    sf = (request.args.get('status') or '').strip()
    stmt = select(Order).order_by(Order.created_at.desc())
    if sf in STATUSES:
        stmt = stmt.where(Order.status == sf)
    orders = [{'id': o.id, 'number': o.number,
               'user': (o.user.full_name or o.user.username) if o.user else '—',
               'created_at': o.created_at, 'items_count': len(o.items),
               'total': o.total, 'status': o.status}
              for o in db.session.scalars(stmt)]
    return render_template('admin_orders.html', orders=orders, status_filter=sf)


# ---------- Пользователи ----------
# ... existing code ...
@no_store
@admin_required
def admin_users():
    q = _qs(request.args.get('q'), max_len=64)   # было: _qs(..., 64)
    page = _int(request.args.get('page', 1))
    # ... rest unchanged ...
    per = 20
    stmt = select(User)
    if q:
        lk = f'%{q.lower()}%'
        stmt = stmt.where(or_(func.lower(User.username).like(lk),
                              func.lower(func.coalesce(User.full_name, '')).like(lk),
                              func.lower(func.coalesce(User.email, '')).like(lk)))
    total = db.session.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    pages = max(1, (total + per - 1) // per)
    page = max(1, min(page, pages))
    us = db.session.scalars(stmt.order_by(User.id)
                            .offset((page - 1) * per).limit(per)).all()
    oc = dict(db.session.execute(select(Order.user_id, func.count(Order.id))
                                 .group_by(Order.user_id)).all())
    fc = dict(db.session.execute(select(Favorite.user_id, func.count(Favorite.product_id))
                                 .group_by(Favorite.user_id)).all())
    users = [{'id': u.id, 'username': u.username, 'full_name': u.full_name or '',
              'email': u.email or '', 'is_admin': bool(u.is_admin),
              'created_at': u.created_at, 'orders': oc.get(u.id, 0),
              'favorites': fc.get(u.id, 0), 'is_probe': is_probe(u.username),
              'must_change_password': bool(u.must_change_password),
              'temp_password_expires_at': u.temp_password_expires_at}
             for u in us]
    probe_count = sum(1 for x in db.session.scalars(select(User.username)).all()
                      if is_probe(x))
    return render_template('admin_users.html', users=users, q=q, page=page,
                           pages=pages, total=total, probe_count=probe_count,
                           current_user_id=session.get('user_id'))


@admin_required
def admin_user_toggle_admin(uid):
    validate_csrf()
    if uid == session['user_id']:
        flash('Нельзя снять администратора с себя', 'danger')
        return redirect(url_for('admin_users'))
    with lock:
        t = db.session.get(User, uid)
        if not t:
            flash('Пользователь не найден', 'danger')
            return redirect(url_for('admin_users'))
        if t.is_admin and admins_count() <= 1:
            flash('Нельзя снять последнего администратора', 'danger')
            return redirect(url_for('admin_users'))
        t.is_admin = not t.is_admin
        t.session_version = int(t.session_version or 1) + 1
        state, name = t.is_admin, t.username
        commit()
    audit('user_toggle_admin', name, f'new_is_admin={state}')
    flash(f"Пользователь {name} — "
          f"{'администратор' if state else 'обычный пользователь'}", 'success')
    return redirect(url_for('admin_users'))


@admin_required
def admin_user_delete(uid):
    validate_csrf()
    if uid == session['user_id']:
        flash('Нельзя удалить себя', 'danger')
        return redirect(url_for('admin_users'))
    with lock:
        t = db.session.get(User, uid)
        if not t:
            flash('Пользователь не найден', 'danger')
            return redirect(url_for('admin_users'))
        if t.is_admin and admins_count() <= 1:
            flash('Нельзя удалить последнего администратора', 'danger')
            return redirect(url_for('admin_users'))
        name = t.username
        purge_user(uid, name)
        commit()
    audit('user_delete', name)
    flash(f'Пользователь {name} удалён', 'success')
    return redirect(url_for('admin_users'))


@no_store
@admin_required
def admin_user_reset_password(uid):
    import secrets
    from werkzeug.security import generate_password_hash
    validate_csrf()
    with lock:
        t = db.session.get(User, uid)
        if not t:
            flash('Пользователь не найден', 'danger')
            return redirect(url_for('admin_users'))
        tmp = secrets.token_urlsafe(12)
        t.password_hash = generate_password_hash(tmp, method='scrypt')
        # A06-1: временный пароль помечается обязательным к смене и получает TTL.
        # session_version++ инвалидирует все уже открытые сессии пользователя.
        t.session_version = int(t.session_version or 1) + 1
        t.must_change_password = True
        t.temp_password_expires_at = datetime.now() + TEMP_PASSWORD_TTL
        name = t.username
        expires_at = t.temp_password_expires_at
        commit()
    audit('user_reset_password', name,
          f'must_change=True expires={expires_at.isoformat(timespec="seconds")}')
    return render_template('admin_temp_password.html',
                           username=name, password=tmp, expires_at=expires_at)


@admin_required
def admin_users_cleanup_probes():
    validate_csrf()
    me = session['user_id']
    with lock:
        probes = [u for u in db.session.scalars(select(User)).all()
                  if is_probe(u.username) and u.id != me]
        nu = len(probes); no = nf = 0
        for u in probes:
            nf += db.session.scalar(select(func.count()).select_from(Favorite)
                                    .where(Favorite.user_id == u.id)) or 0
            no += purge_user(u.id, u.username)
        commit()
    audit('users_cleanup_probes', '', f'removed={nu} orders={no}')
    flash(f'Удалено тестовых: {nu}, заказов: {no}, избранного: {nf}', 'success')
    return redirect(url_for('admin_users'))


# ---------- Статистика ----------
@admin_required
def admin_stats():
    A = ('processing', 'ready', 'issued')
    rev = db.session.scalar(select(func.sum(Order.total)).where(Order.status.in_(A))) or Decimal(0)
    an = db.session.scalar(select(func.count()).select_from(Order)
                           .where(Order.status.in_(A))) or 0
    on = db.session.scalar(select(func.count()).select_from(Order)) or 0
    by_st = dict(db.session.execute(select(Order.status, func.count())
                                    .group_by(Order.status)).all())
    top_p = [{'article': p.article, 'name': p.name, 'color': p.color,
              'qty': q, 'sum': s}
             for p, q, s in db.session.execute(
                 select(Product, func.sum(OrderItem.qty_m), func.sum(OrderItem.total))
                 .join(OrderItem, OrderItem.product_id == Product.id)
                 .join(Order, Order.id == OrderItem.order_id)
                 .where(Order.status != 'cancelled')
                 .group_by(Product.id)
                 .order_by(func.sum(OrderItem.total).desc()).limit(5)).all()]
    top_c = [{'username': u.username, 'full_name': u.full_name or '—',
              'sum': s, 'orders': c}
             for u, s, c in db.session.execute(
                 select(User, func.sum(Order.total), func.count(Order.id))
                 .join(Order, Order.user_id == User.id)
                 .where(Order.status.in_(A))
                 .group_by(User.id)
                 .order_by(func.sum(Order.total).desc()).limit(5)).all()]
    today = datetime.now().date()
    daily = {today - timedelta(days=i): Decimal(0) for i in range(13, -1, -1)}
    cutoff = datetime.combine(min(daily), datetime.min.time())
    for d, s in db.session.execute(
            select(func.date(Order.created_at), func.sum(Order.total))
            .where(Order.status.in_(A), Order.created_at >= cutoff)
            .group_by(func.date(Order.created_at))).all():
        k = datetime.fromisoformat(d).date() if isinstance(d, str) else d
        if k in daily:
            daily[k] = s
    ds = sorted(daily.items())
    low = sorted(db.session.scalars(select(Product).where(Product.stock_m < 200)).all(),
                 key=lambda p: p.stock_m)[:10]
    sv = db.session.scalar(select(func.sum(Product.stock_m * Product.price_per_m))) or Decimal(0)
    return render_template(
        'admin_stats.html', revenue=rev,
        avg_check=rev / an if an else Decimal(0),
        orders_total=on, active_orders=an,
        users_total=db.session.scalar(select(func.count()).select_from(User)) or 0,
        products_total=db.session.scalar(select(func.count()).select_from(Product)) or 0,
        stock_value=sv, by_status=Counter(by_st),
        top_products=top_p, top_clients=top_c,
        daily_labels=[d.strftime('%d.%m') for d, _ in ds],
        daily_values=[float(s) for _, s in ds],
        low_stock=low)


@admin_required
def admin_audit():
    items = db.session.scalars(
        select(AuditLog).order_by(AuditLog.ts.desc()).limit(500)).all()
    return render_template('admin_audit.html', items=items)


def register_routes(app):
    app.add_url_rule('/admin/orders',                       view_func=admin_orders)
    app.add_url_rule('/admin/orders/<int:oid>/status',
                     view_func=admin_change_status,          methods=['POST'])
    app.add_url_rule('/admin/users',                        view_func=admin_users)
    app.add_url_rule('/admin/users/<int:uid>/toggle_admin',
                     view_func=admin_user_toggle_admin,      methods=['POST'])
    app.add_url_rule('/admin/users/<int:uid>/delete',
                     view_func=admin_user_delete,            methods=['POST'])
    app.add_url_rule('/admin/users/<int:uid>/reset_password',
                     view_func=admin_user_reset_password,    methods=['POST'])
    app.add_url_rule('/admin/users/cleanup_probes',
                     view_func=admin_users_cleanup_probes,   methods=['POST'])
    app.add_url_rule('/admin/stats',                        view_func=admin_stats)
    app.add_url_rule('/admin/audit',                        view_func=admin_audit)