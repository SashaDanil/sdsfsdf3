"""Каталог, экспорт, избранное, главная."""
import csv
import io

from flask import (Response, flash, redirect, render_template, request,
                   session, url_for)
from sqlalchemy import func, select

from ..extensions import commit, db, lock
from ..models import Favorite, Order, Product
from ..security import login_required, validate_csrf
from ..utils import (_int, _qs, fav_pids, list_favorites, list_products,
                     orders_list_data)


def _shop_page(tpl):
    q = _qs(request.args.get('q'), max_len=64)
    page = _int(request.args.get('page', 1))
    res = list_products(q, page)
    items, total, pages, page = res.items, res.total, res.pages, res.page
    fav = fav_pids(session['user_id'])
    return render_template(tpl, products=items, q=q, page=page, pages=pages,
                           total=total, is_fav=lambda pid: pid in fav)


@login_required
def index():
    q = _qs(request.args.get('q'), max_len=64)
    page = _int(request.args.get('page', 1))
    res = list_products(q, page)
    items, total, pages, page = res.items, res.total, res.pages, res.page
    fav = fav_pids(session['user_id'])
    return render_template(
        'index.html',
        products_count=db.session.scalar(
            select(func.count()).select_from(Product)) or 0,
        orders_count=db.session.scalar(
            select(func.count()).select_from(Order)) or 0,
        my_orders=orders_list_data(session['user_id'])[:5],
        products=items, q=q, page=page, pages=pages, total=total,
        is_fav=lambda pid: pid in fav)


@login_required
def products():
    return _shop_page('products.html')


@login_required
def products_export_csv():
    items = db.session.scalars(
        select(Product).order_by(Product.article)).all()
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=';')
    w.writerow(['Артикул', 'Наименование', 'Цвет', 'Ширина, мм',
                'Цена, ₽/м', 'Остаток, м'])
    for p in items:
        w.writerow([p.article, p.name, p.color, p.width_mm,
                    f'{p.price_per_m:.2f}', f'{p.stock_m:.2f}'])
    return Response(
        '\ufeff' + buf.getvalue(),
        mimetype='text/csv; charset=utf-8',
        headers={'Content-Disposition':
                 'attachment; filename=products.csv'})


@login_required
def favorites_view():
    return render_template('favorites.html',
                           products=list_favorites(session['user_id']),
                           is_fav=lambda pid: True)


@login_required
def favorites_toggle(pid):
    validate_csrf()
    uid = session['user_id']
    with lock:
        if not db.session.get(Product, pid):
            flash('Товар не найден', 'danger')
            return redirect(url_for('index'))
        e = db.session.get(Favorite, (uid, pid))
        if e:
            db.session.delete(e)
            flash('Удалено из избранного', 'info')
        else:
            db.session.add(Favorite(user_id=uid, product_id=pid))
            flash('Добавлено в избранное', 'success')
        commit()
    return redirect(url_for('index'))


def register_routes(app):
    app.add_url_rule('/', view_func=index)
    app.add_url_rule('/products', view_func=products)
    app.add_url_rule('/products/export.csv', view_func=products_export_csv)
    app.add_url_rule('/favorites', view_func=favorites_view)
    app.add_url_rule('/favorites/toggle/<int:pid>',
                     view_func=favorites_toggle, methods=['POST'])