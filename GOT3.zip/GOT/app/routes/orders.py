"""Просмотр заказов покупателем."""
from flask import Response, abort, render_template, session, url_for
import qrcode
import qrcode.image.svg

from ..extensions import db
from ..models import Order
from ..security import login_required
from ..utils import orders_list_data


@login_required
def orders_list():
    return render_template(
        'orders.html',
        orders=orders_list_data(session['user_id']),
    )


@login_required
def order_detail(oid):
    o = db.session.get(Order, oid)
    if not o or o.user_id != session['user_id']:
        abort(404)

    lines = [{
        'article': i.product.article if i.product else '—',
        'name': i.product.name if i.product else '—',
        'color': i.product.color if i.product else '',
        'width_mm': i.product.width_mm if i.product else 0,
        'qty_m': i.qty_m,
        'price': i.price,
        'total': i.total,
    } for i in o.items]

    return render_template(
        'order_detail.html',
        order={
            'id': o.id,
            'number': o.number,
            'status': o.status,
            'total': o.total,
            'created_at': o.created_at,
        },
        lines=lines,
    )


@login_required
def order_qr(oid):
    """SVG QR-код заказа."""
    o = db.session.get(Order, oid)
    if not o or o.user_id != session['user_id']:
        abort(404)

    payload = (
        f"Заказ {o.number}\n"
        f"Сумма: {o.total} ₽\n"
        f"{url_for('order_detail', oid=o.id, _external=True)}"
    )

    img = qrcode.make(
        payload,
        image_factory=qrcode.image.svg.SvgPathImage,
        box_size=8,
        border=2,
    )
    svg = img.to_string()
    if isinstance(svg, str):
        svg = svg.encode('utf-8')

    return Response(
        svg,
        mimetype='image/svg+xml',
        headers={'Cache-Control': 'no-store'},
    )


def register_routes(app):
    app.add_url_rule('/orders', view_func=orders_list)
    app.add_url_rule('/orders/<int:oid>', view_func=order_detail)
    app.add_url_rule('/orders/<int:oid>/qr.svg', view_func=order_qr)