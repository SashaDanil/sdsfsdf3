"""A08-3: локальное резервное копирование SQLite.

НЕ копируем файл БД через cp — при journal_mode=WAL и активных
транзакциях копия ловится битой. Используем VACUUM INTO: SQLite сам
пишет консистентный снимок. Затем gzip и (опционально) AES-GCM.

Каталог назначения — env BACKUP_DIR. По умолчанию ./backups рядом
с БД. Ротация — BACKUP_KEEP последних файлов.
"""
import gzip
import os
import shutil
import threading
from datetime import datetime
from pathlib import Path

from sqlalchemy import text

from .config import DB_PATH, log
from .extensions import db

BACKUP_DIR = Path(os.environ.get('BACKUP_DIR', str(DB_PATH.parent / 'backups')))
BACKUP_KEEP = int(os.environ.get('BACKUP_KEEP', '7') or '7')
BACKUP_INTERVAL_H = int(os.environ.get('BACKUP_INTERVAL_HOURS', '24') or '24')
BACKUP_AES_KEY = os.environ.get('BACKUP_AES_KEY', '').strip()
BACKUP_ENABLED = os.environ.get('BACKUP_ENABLED', '1') == '1'


def _encrypt_available() -> bool:
    try:
        import cryptography  # noqa: F401
        return True
    except ImportError:
        return False


def _use_encryption() -> bool:
    return bool(BACKUP_AES_KEY and len(BACKUP_AES_KEY) == 64
                and _encrypt_available())


def _snapshot(dst: Path) -> None:
    """VACUUM INTO — атомарный снимок живой SQLite без остановки сервиса."""
    path_sql = str(dst).replace("'", "''")
    db.session.execute(text(f"VACUUM INTO '{path_sql}'"))


def _gzip_file(src: Path, dst: Path) -> None:
    with src.open('rb') as fin, gzip.open(dst, 'wb', compresslevel=6) as fout:
        shutil.copyfileobj(fin, fout, length=1024 * 1024)


def _encrypt_file(src: Path, dst: Path) -> None:
    """AES-GCM, если cryptography установлена и ключ задан. Иначе копия."""
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    aes = AESGCM(bytes.fromhex(BACKUP_AES_KEY))
    nonce = os.urandom(12)
    ct = aes.encrypt(nonce, src.read_bytes(), associated_data=b'italcozhda-bkp')
    dst.write_bytes(nonce + ct)   # nonce в префиксе


def _rotate() -> int:
    files = sorted(BACKUP_DIR.glob('backup-*.sqlite3.*'),
                   key=lambda p: p.stat().st_mtime)
    extra = len(files) - BACKUP_KEEP
    removed = 0
    for f in files[:max(0, extra)]:
        try:
            f.unlink()
            removed += 1
            log.info('backup rotate: удалён %s', f.name)
        except OSError:
            log.exception('backup rotate: не удалось удалить %s', f.name)
    return removed


def run_backup() -> dict:
    """Возвращает {'ok': bool, 'path': str, 'size': int, 'error': str}."""
    if not BACKUP_ENABLED:
        return {'ok': False, 'path': '', 'size': 0, 'error': 'отключено'}

    try:
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return {'ok': False, 'path': '', 'size': 0, 'error': f'mkdir: {exc}'}

    stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
    raw = BACKUP_DIR / f'.tmp-{stamp}.sqlite3'
    gz = BACKUP_DIR / f'backup-{stamp}.sqlite3.gz'
    final = (BACKUP_DIR / f'backup-{stamp}.sqlite3.gz.enc'
             if _use_encryption() else gz)

    try:
        _snapshot(raw)
    except Exception as exc:
        log.exception('backup: VACUUM INTO упал')
        raw.unlink(missing_ok=True)
        return {'ok': False, 'path': '', 'size': 0, 'error': f'snapshot: {exc}'}

    try:
        _gzip_file(raw, gz)
    finally:
        raw.unlink(missing_ok=True)

    if final != gz:
        try:
            _encrypt_file(gz, final)
        except Exception as exc:
            log.exception('backup: шифрование упало')
            gz.unlink(missing_ok=True)
            return {'ok': False, 'path': '', 'size': 0, 'error': f'encrypt: {exc}'}
        gz.unlink(missing_ok=True)

    removed = _rotate()
    size = final.stat().st_size
    log.info('backup: OK path=%s size=%d rotated=%d', final, size, removed)
    return {'ok': True, 'path': str(final), 'size': size, 'error': ''}


def start_scheduler(app) -> threading.Event | None:
    if not BACKUP_ENABLED:
        log.info('Backup отключён: BACKUP_ENABLED=0')
        return None
    stop = threading.Event()

    def _run():
        # Первый бэкап — через 5 минут после старта, чтобы не тормозить boot
        if stop.wait(300):
            return
        interval = max(1, BACKUP_INTERVAL_H) * 3600
        while not stop.is_set():
            with app.app_context():
                try:
                    res = run_backup()
                    if not res['ok']:
                        log.error('backup failed: %s', res['error'])
                except Exception:
                    log.exception('backup: необработанная ошибка')
            if stop.wait(interval):
                return

    threading.Thread(target=_run, name='local-backup', daemon=True).start()
    log.info('Backup scheduler: dir=%s, каждые %d ч, хранить %d',
             BACKUP_DIR, BACKUP_INTERVAL_H, BACKUP_KEEP)
    return stop