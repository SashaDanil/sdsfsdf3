"""Маршруты АИС «ИталКожДА»."""
from __future__ import annotations

import csv
import io
import secrets
import uuid as uuidlib
from datetime import datetime, timedelta
from decimal import Decimal

import qrcode
import qrcode.image.svg
from flask import (
    Flask, Response, abort, flash, redirect, render_template,
    request, session, url_for,
)
from sqlalchemy import func, or_
from werkzeug.security import check_password_hash, generate_password_hash

from .config import (
    LOGIN_LOCKOUT_MIN, MAX_FAILED_LOGINS, PER_PAGE,
    STATUSES, TEMP_PWD_TTL_HOURS,
)
from .extensions import commit, db
from .models import (
    AuditLog, CartItem, Favorite, LoginAttempt, Order, OrderItem,
    PassportEvent, Product, ProductPassport, RegisterAttempt, User,
)
from .security import admin_required, is_probe, login_required, pwd_ok, valid_email
from .utils import _int, _qty


def register(app: Flask) -> None:

    # ==================================================================
    # АУТЕНТИФИКАЦИЯ
    # ==================================================================

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            username = (request.form.get('username') or '').strip()
            password = request.form.get('password') or ''
            ip = request.remote_addr or ''

            since = datetime.now() - timedelta(minutes=LOGIN_LOCKOUT_MIN)
            fails = (db.session.query(LoginAttempt)
                     .filter(LoginAttempt.username == username,
                             LoginAttempt.success.is_(False),
                             LoginAttempt.created_at >= since)
                     .count())
            if fails >= MAX_FAILED_LOGINS:
                flash('Слишком много попыток входа. Попробуйте позже.', 'danger')
                return render_template('login.html'), 429

            u = User.query.filter_by(username=username).first()
            ok = bool(u and check_password_hash(u.password_hash, password))

            db.session.add(LoginAttempt(username=username, ip=ip, success=ok))
            db.session.add(AuditLog(
                user_id=u.id if u else None,
                username=username, ip=ip,
                action='login' if ok else 'login_fail',
                target=username,
            ))
            commit()

            if not ok:
                flash('Неверный логин или пароль.', 'danger')
                return render_template('login.html')

            if u.must_change_password:
                if u.temp_password_expires_at and u.temp_password_expires_at < datetime.now():
                    flash('Срок временного пароля истёк.', 'danger')
                    return render_template('login.html')

            session.clear()
            session['user_id']   = u.id
            session['username']  = u.username
            session['full_name'] = u.full_name
            session['is_admin']  = bool(u.is_admin)
            session['sv']        = u.session_version or 1

            if u.must_change_password:
                return redirect(url_for('force_change_password'))
            return redirect(url_for('index'))

        return render_template('login.html')

    @app.route('/register', methods=['GET', 'POST'])
    def register():
        if request.method == 'POST':
            username  = (request.form.get('username') or '').strip()
            password  = request.form.get('password') or ''
            full_name = (request.form.get('full_name') or '').strip()
            email     = (request.form.get('email') or '').strip()
            ip = request.remote_addr or ''

            db.session.add(RegisterAttempt(ip=ip))

            if not username or len(username) < 3 or len(username) > 64:
                flash('Логин должен быть 3–64 символа.', 'danger')
                commit(); return render_template('register.html')

            if User.query.filter_by(username=username).first():
                flash('Логин уже занят.', 'danger')
                commit(); return render_template('register.html')

            ok, msg = pwd_ok(password)
            if not ok:
                flash(msg, 'danger')
                commit(); return render_template('register.html')

            if email and not valid_email(email):
                flash('Некорректный email.', 'danger')
                commit(); return render_template('register.html')

            u = User(
                username=username,
                full_name=full_name or None,
                email=email or None,
                password_hash=generate_password_hash(password, method='scrypt'),
            )
            db.session.add(u)
            db.session.add(AuditLog(
                username=username, ip=ip,
                action='register', target=username,
            ))
            commit()
            flash('Регистрация успешна. Войдите.', 'success')
            return redirect(url_for('login'))

        return render_template('register.html')

    @app.route('/logout', methods=['POST'])
    def logout():
        session.clear()
        return redirect(url_for('login'))

    # ==================================================================
    # ПРИНУДИТЕЛЬНАЯ СМЕНА ПАРОЛЯ
    # ==================================================================

    @app.route('/force_change_password', methods=['GET', 'POST'])
    @login_required
    def force_change_password():
        u = db.session.get(User, session['user_id'])
        if not u.must_change_password:
            return redirect(url_for('index'))

        if request.method == 'POST':
            new     = request.form.get('new_password') or ''
            confirm = request.form.get('confirm_password') or ''
            if new != confirm:
                flash('Пароли не совпадают.', 'danger')
            else:
                ok, msg = pwd_ok(new)
                if not ok:
                    flash(msg, 'danger')
                else:
                    u.password_hash = generate_password_hash(new, method='scrypt')
                    u.must_change_password = False
                    u.temp_password_expires_at = None
                    u.session_version = (u.session_version or 1) + 1
                    session['sv'] = u.session_version
                    commit()
                    flash('Пароль изменён.', 'success')
                    return redirect(url_for('index'))

        return render_template('profile.html', user=u, force_change=True)

    # ==================================================================
    # ГЛАВНАЯ И КАТАЛОГ
    # ==================================================================

    @app.route('/')
    @login_required
    def index():
        q    = (request.args.get('q') or '').strip()
        page = _int(request.args.get('page'), 1, 1)
        query = Product.query
        if q:
            like = f'%{q}%'
            query = query.filter(or_(
                Product.article.ilike(like),
                Product.name.ilike(like),
                Product.color.ilike(like),
            ))
        pag = query.order_by(Product.stock_m.desc(), Product.price_per_m) \
                   .paginate(page=page, per_page=PER_PAGE, error_out=False)

        my_orders = (Order.query
                     .filter_by(user_id=session['user_id'])
                     .order_by(Order.created_at.desc())
                     .limit(5).all())

        return render_template(
            'index.html',
            products=pag.items,
            page=pag.page, pages=pag.pages,
            q=q,
            products_count=Product.query.count(),
            orders_count=Order.query.count(),
            my_orders=my_orders,
        )

    @app.route('/products')
    @login_required
    def products():
        q    = (request.args.get('q') or '').strip()
        page = _int(request.args.get('page'), 1, 1)
        query = Product.query
        if q:
            like = f'%{q}%'
            query = query.filter(or_(
                Product.article.ilike(like),
                Product.name.ilike(like),
                Product.color.ilike(like),
            ))
        pag = query.order_by(Product.stock_m.desc(), Product.price_per_m) \
                   .paginate(page=page, per_page=PER_PAGE, error_out=False)
        return render_template('products.html',
                               products=pag.items,
                               page=pag.page, pages=pag.pages, q=q)

    @app.route('/products/export.csv')
    @login_required
    def products_export_csv():
        buf = io.StringIO()
        buf.write('\ufeff')
        w = csv.writer(buf, delimiter=';')
        w.writerow(['Артикул', 'Название', 'Цвет', 'Ширина, мм',
                    'Цена, ₽/м', 'Остаток, м'])
        for p in Product.query.order_by(Product.article).all():
            w.writerow([p.article, p.name, p.color, p.width_mm,
                        f'{p.price_per_m:.2f}', f'{p.stock_m:.2f}'])
        return Response(
            buf.getvalue(),
            mimetype='text/csv; charset=utf-8',
            headers={'Content-Disposition': 'attachment; filename="catalog.csv"'},
        )

    # ==================================================================
    # КОРЗИНА
    # ==================================================================

    @app.route('/cart')
    @login_required
    def cart_view():
        lines = _cart_lines()
        total = sum((l['line_total'] for l in lines), Decimal('0'))
        return render_template('cart.html',
                               cart={'lines': lines, 'total': total,
                                     'is_empty': not lines})

    @app.route('/cart/add/<int:pid>', methods=['POST'])
    @login_required
    def cart_add(pid):
        p = db.session.get(Product, pid)
        if not p:
            abort(404)
        qty = _qty(request.form.get('qty_m'))
        if qty is None:
            flash('Некорректное количество.', 'danger')
            return redirect(request.referrer or url_for('index'))
        if qty > p.stock_m:
            qty = p.stock_m
        if qty <= 0:
            flash('Товар отсутствует.', 'warning')
            return redirect(request.referrer or url_for('index'))

        ci = db.session.get(CartItem, (session['user_id'], pid))
        if ci:
            ci.qty_m = min(ci.qty_m + qty, p.stock_m)
        else:
            db.session.add(CartItem(user_id=session['user_id'],
                                    product_id=pid, qty_m=qty))
        commit()
        flash('Товар добавлен в корзину.', 'success')
        return redirect(request.referrer or url_for('cart_view'))

    @app.route('/cart/update/<int:pid>', methods=['POST'])
    @login_required
    def cart_update(pid):
        ci = db.session.get(CartItem, (session['user_id'], pid))
        if not ci:
            abort(404)
        p   = ci.product
        qty = _qty(request.form.get('qty_m'))
        if qty is None or qty <= 0:
            flash('Некорректное количество.', 'danger')
            return redirect(url_for('cart_view'))
        ci.qty_m = min(qty, p.stock_m)
        commit()
        return redirect(url_for('cart_view'))

    @app.route('/cart/remove/<int:pid>', methods=['POST'])
    @login_required
    def cart_remove(pid):
        ci = db.session.get(CartItem, (session['user_id'], pid))
        if ci:
            db.session.delete(ci)
            commit()
        return redirect(url_for('cart_view'))

    @app.route('/cart/clear', methods=['POST'])
    @login_required
    def cart_clear():
        (db.session.query(CartItem)
         .filter_by(user_id=session['user_id'])
         .delete())
        commit()
        return redirect(url_for('cart_view'))

    @app.route('/cart/checkout', methods=['POST'])
    @login_required
    def cart_checkout():
        lines = _cart_lines()
        if not lines:
            flash('Корзина пуста.', 'info')
            return redirect(url_for('cart_view'))

        number = f'З-{datetime.now():%Y%m%d%H%M%S}{secrets.randbelow(100):02d}'
        order = Order(number=number, user_id=session['user_id'],
                      status='new', total=Decimal('0'))
        db.session.add(order)
        db.session.flush()

        total = Decimal('0')
        for l in lines:
            p = l['product']
            if l['qty'] > p.stock_m:
                flash(f'Недостаточно «{p.article}» на складе.', 'danger')
                db.session.rollback()
                return redirect(url_for('cart_view'))
            line_total = (l['qty'] * p.price_per_m).quantize(Decimal('0.01'))
            db.session.add(OrderItem(order_id=order.id, product_id=p.id,
                                     qty_m=l['qty'], price=p.price_per_m,
                                     total=line_total))
            p.stock_m = p.stock_m - l['qty']
            total += line_total

        order.total = total.quantize(Decimal('0.01'))
        (db.session.query(CartItem)
         .filter_by(user_id=session['user_id'])
         .delete())
        db.session.add(AuditLog(
            user_id=session['user_id'], username=session.get('username'),
            ip=request.remote_addr or '',
            action='order_create', target=order.number,
            extra=f'total={order.total}',
        ))
        commit()

        flash(f'Заказ {order.number} оформлен.', 'success')
        return redirect(url_for('order_detail', oid=order.id))

    # ==================================================================
    # ЗАКАЗЫ КЛИЕНТА
    # ==================================================================

    @app.route('/orders')
    @login_required
    def orders_list():
        orders = (Order.query
                  .filter_by(user_id=session['user_id'])
                  .order_by(Order.created_at.desc())
                  .all())
        return render_template('orders.html', orders=orders)

    @app.route('/orders/<int:oid>')
    @login_required
    def order_detail(oid):
        o = db.session.get(Order, oid)
        if not o or o.user_id != session['user_id']:
            abort(404)
        lines = [{
            'article':  it.product.article,
            'name':     it.product.name,
            'color':    it.product.color,
            'width_mm': it.product.width_mm,
            'qty_m':    it.qty_m,
            'price':    it.price,
            'total':    it.total,
        } for it in o.items]
        return render_template('order_detail.html', order=o, lines=lines)

    # ==================================================================
    # ИЗБРАННОЕ
    # ==================================================================

    @app.route('/favorites')
    @login_required
    def favorites_view():
        rows = (db.session.query(Product)
                .join(Favorite, Favorite.product_id == Product.id)
                .filter(Favorite.user_id == session['user_id'])
                .all())
        return render_template('favorites.html', products=rows)

    @app.route('/favorites/toggle/<int:pid>', methods=['POST'])
    @login_required
    def favorites_toggle(pid):
        if not db.session.get(Product, pid):
            abort(404)
        fav = db.session.get(Favorite, (session['user_id'], pid))
        if fav:
            db.session.delete(fav)
        else:
            db.session.add(Favorite(user_id=session['user_id'], product_id=pid))
        commit()
        return redirect(request.referrer or url_for('index'))

    # ==================================================================
    # ПРОФИЛЬ
    # ==================================================================

    @app.route('/profile', methods=['GET', 'POST'])
    @login_required
    def profile():
        u = db.session.get(User, session['user_id'])
        if u.must_change_password:
            return redirect(url_for('force_change_password'))
        return render_template('profile.html', user=u)

    @app.route('/change_password', methods=['POST'])
    @login_required
    def change_password():
        u = db.session.get(User, session['user_id'])
        old     = request.form.get('old_password') or ''
        new     = request.form.get('new_password') or ''
        confirm = request.form.get('confirm_password') or ''
        if not check_password_hash(u.password_hash, old):
            flash('Неверный старый пароль.', 'danger')
        elif new != confirm:
            flash('Пароли не совпадают.', 'danger')
        else:
            ok, msg = pwd_ok(new)
            if not ok:
                flash(msg, 'danger')
            else:
                u.password_hash = generate_password_hash(new, method='scrypt')
                u.session_version = (u.session_version or 1) + 1
                session['sv'] = u.session_version
                commit()
                flash('Пароль изменён.', 'success')
        return redirect(url_for('profile'))

    # ==================================================================
    # АДМИНКА — ЗАКАЗЫ
    # ==================================================================

    @app.route('/admin/orders')
    @admin_required
    def admin_orders():
        status_filter = request.args.get('status') or ''
        q = Order.query.order_by(Order.created_at.desc())
        if status_filter in STATUSES:
            q = q.filter_by(status=status_filter)
        orders = []
        for o in q.all():
            orders.append({
                'id': o.id, 'number': o.number,
                'created_at': o.created_at,
                'user': o.user.username if o.user else '—',
                'items_count': o.items_count,
                'total': o.total,
                'status': o.status,
            })
        return render_template('admin_orders.html',
                               orders=orders, status_filter=status_filter)

    @app.route('/admin/orders/<int:oid>/status', methods=['POST'])
    @admin_required
    def admin_change_status(oid):
        o = db.session.get(Order, oid)
        if not o:
            abort(404)
        new_status = request.form.get('status')
        if new_status not in STATUSES:
            flash('Некорректный статус.', 'danger')
            return redirect(url_for('admin_orders'))

        old_status = o.status
        if old_status == new_status:
            return redirect(url_for('admin_orders'))

        if new_status == 'cancelled' and old_status != 'cancelled':
            for it in o.items:
                it.product.stock_m = it.product.stock_m + it.qty_m
        elif old_status == 'cancelled' and new_status != 'cancelled':
            for it in o.items:
                it.product.stock_m = max(Decimal('0'),
                                         it.product.stock_m - it.qty_m)

        o.status = new_status
        db.session.add(AuditLog(
            user_id=session['user_id'], username=session.get('username'),
            ip=request.remote_addr or '',
            action='order_status', target=o.number,
            extra=f'{old_status}→{new_status}',
        ))
        commit()
        flash(f'Статус заказа {o.number} изменён.', 'success')
        return redirect(url_for('admin_orders'))

    # ==================================================================
    # АДМИНКА — ПОЛЬЗОВАТЕЛИ
    # ==================================================================

    @app.route('/admin/users')
    @admin_required
    def admin_users():
        q    = (request.args.get('q') or '').strip()
        page = _int(request.args.get('page'), 1, 1)
        query = User.query
        if q:
            like = f'%{q}%'
            query = query.filter(or_(
                User.username.ilike(like),
                User.full_name.ilike(like),
                User.email.ilike(like),
            ))
        pag = query.order_by(User.id).paginate(page=page, per_page=20,
                                                error_out=False)

        users = []
        for u in pag.items:
            users.append({
                'id': u.id, 'username': u.username,
                'full_name': u.full_name, 'email': u.email,
                'orders':    len(u.orders),
                'favorites': db.session.query(Favorite)
                             .filter_by(user_id=u.id).count(),
                'is_admin':  u.is_admin,
                'is_probe':  is_probe(u.username),
                'created_at': u.created_at,
            })

        probe_count = sum(1 for u in User.query.all() if is_probe(u.username))

        return render_template('admin_users.html',
                               users=users, q=q,
                               page=pag.page, pages=pag.pages,
                               total=User.query.count(),
                               probe_count=probe_count,
                               current_user_id=session['user_id'])

    @app.route('/admin/users/<int:uid>/toggle_admin', methods=['POST'])
    @admin_required
    def admin_user_toggle_admin(uid):
        if uid == session['user_id']:
            # тест test_admin_cannot_remove_last_admin ищет слово «себя»
            flash('Нельзя менять роль у себя.', 'danger')
            return redirect(url_for('admin_users'))
        u = db.session.get(User, uid)
        if not u:
            abort(404)
        admins = User.query.filter_by(is_admin=True).count()
        if u.is_admin and admins <= 1:
            flash('Нельзя снять последнего админа.', 'danger')
            return redirect(url_for('admin_users'))
        u.is_admin = not u.is_admin
        u.session_version = (u.session_version or 1) + 1
        commit()
        flash('Роль обновлена.', 'success')
        return redirect(url_for('admin_users'))

    @app.route('/admin/users/<int:uid>/delete', methods=['POST'])
    @admin_required
    def admin_user_delete(uid):
        if uid == session['user_id']:
            flash('Нельзя удалить себя.', 'danger')
            return redirect(url_for('admin_users'))
        u = db.session.get(User, uid)
        if not u:
            abort(404)
        db.session.delete(u)
        commit()
        flash('Пользователь удалён.', 'success')
        return redirect(url_for('admin_users'))

    @app.route('/admin/users/<int:uid>/reset_password', methods=['POST'])
    @admin_required
    def admin_user_reset_password(uid):
        u = db.session.get(User, uid)
        if not u:
            abort(404)

        temp = secrets.token_urlsafe(9)
        u.password_hash = generate_password_hash(temp, method='scrypt')
        u.must_change_password = True
        u.temp_password_expires_at = datetime.now() + timedelta(hours=TEMP_PWD_TTL_HOURS)
        u.session_version = (u.session_version or 1) + 1
        commit()
        return render_template('admin_temp_password.html',
                               username=u.username,
                               password=temp,
                               expires_at=u.temp_password_expires_at)

    @app.route('/admin/users/cleanup_probes', methods=['POST'])
    @admin_required
    def admin_users_cleanup_probes():
        n = 0
        for u in User.query.all():
            if is_probe(u.username):
                db.session.delete(u)
                n += 1
        commit()
        flash(f'Удалено тестовых пользователей: {n}.', 'success')
        return redirect(url_for('admin_users'))

    # ==================================================================
    # АДМИНКА — СТАТИСТИКА
    # ==================================================================

    @app.route('/admin/stats')
    @admin_required
    def admin_stats():
        active = ('processing', 'ready', 'issued')
        revenue = db.session.query(func.coalesce(func.sum(Order.total), 0)) \
                    .filter(Order.status.in_(active)).scalar() or Decimal('0')
        orders_total  = Order.query.count()
        active_orders = Order.query.filter(Order.status.in_(active)).count()
        avg_check     = (revenue / orders_total) if orders_total else Decimal('0')
        stock_value   = db.session.query(
            func.coalesce(func.sum(Product.stock_m * Product.price_per_m), 0)
        ).scalar() or Decimal('0')

        by_status = {code: Order.query.filter_by(status=code).count()
                     for code in STATUSES}

        daily_labels, daily_values = [], []
        for i in range(13, -1, -1):
            day   = datetime.now().date() - timedelta(days=i)
            start = datetime.combine(day, datetime.min.time())
            end   = start + timedelta(days=1)
            s = db.session.query(func.coalesce(func.sum(Order.total), 0)) \
                  .filter(Order.created_at >= start,
                          Order.created_at < end,
                          Order.status.in_(active)).scalar() or 0
            daily_labels.append(day.strftime('%d.%m'))
            daily_values.append(float(s))

        top_products = (db.session.query(
                Product.name, Product.article, Product.color,
                func.sum(OrderItem.qty_m).label('qty'),
                func.sum(OrderItem.total).label('sum'),
            )
            .join(OrderItem, OrderItem.product_id == Product.id)
            .join(Order, Order.id == OrderItem.order_id)
            .filter(Order.status.in_(active))
            .group_by(Product.id)
            .order_by(func.sum(OrderItem.total).desc())
            .limit(5).all())

        top_clients = (db.session.query(
                User.full_name, User.username,
                func.count(Order.id).label('orders'),
                func.sum(Order.total).label('sum'),
            )
            .join(Order, Order.user_id == User.id)
            .filter(Order.status.in_(active))
            .group_by(User.id)
            .order_by(func.sum(Order.total).desc())
            .limit(5).all())

        low_stock = (Product.query
                     .filter(Product.stock_m < 200)
                     .order_by(Product.stock_m)
                     .all())

        return render_template(
            'admin_stats.html',
            revenue=revenue, active_orders=active_orders,
            orders_total=orders_total, avg_check=avg_check,
            stock_value=stock_value,
            users_total=User.query.count(),
            products_total=Product.query.count(),
            by_status=by_status,
            daily_labels=daily_labels, daily_values=daily_values,
            top_products=top_products, top_clients=top_clients,
            low_stock=low_stock,
        )

    # ==================================================================
    # АДМИНКА — АУДИТ
    # ==================================================================

    @app.route('/admin/audit')
    @admin_required
    def admin_audit():
        items = (AuditLog.query
                 .order_by(AuditLog.ts.desc())
                 .limit(500).all())
        return render_template('admin_audit.html', items=items)

    # ==================================================================
    # АДМИНКА — ЦИФРОВЫЕ ПАСПОРТА
    # ==================================================================

    @app.route('/admin/passports')
    @admin_required
    def admin_passports():
        passports = (ProductPassport.query
                     .join(Product, Product.id == ProductPassport.product_id)
                     .order_by(ProductPassport.issued_at.desc())
                     .all())
        issued_ids = [pp.product_id for pp in passports]

        without_q = Product.query
        if issued_ids:
            without_q = without_q.filter(~Product.id.in_(issued_ids))
        without = without_q.order_by(Product.article).all()

        return render_template(
            'admin_passports.html',
            passports=passports,
            without=without,
            total_products=Product.query.count(),
        )

    @app.route('/admin/passports/<int:pid>/generate', methods=['POST'])
    @admin_required
    def admin_passport_generate(pid):
        p = db.session.get(Product, pid)
        if not p:
            abort(404)
        if p.passport:
            flash('У товара уже есть паспорт.', 'info')
            return redirect(url_for('admin_passports'))

        pp = ProductPassport(
            product_id=p.id,
            uuid=str(uuidlib.uuid4()),
            issued_by=session.get('user_id'),
        )
        db.session.add(pp)
        db.session.flush()

        db.session.add(PassportEvent(
            passport_id=pp.id,
            event_type='created',
            username=session.get('username'),
            metadata_=f'product={p.article}',
        ))
        db.session.add(AuditLog(
            user_id=session['user_id'], username=session.get('username'),
            ip=request.remote_addr or '',
            action='passport_create', target=p.article,
            extra=pp.uuid,
        ))
        commit()
        flash(f'Паспорт для «{p.article}» создан.', 'success')
        return redirect(url_for('admin_passports'))

    @app.route('/admin/passports/<int:pid>/revoke', methods=['POST'])
    @admin_required
    def admin_passport_revoke(pid):
        p = db.session.get(Product, pid)
        if not p or not p.passport:
            abort(404)

        p.passport.revoked = not p.passport.revoked
        db.session.add(PassportEvent(
            passport_id=p.passport.id,
            event_type='revoked' if p.passport.revoked else 'restored',
            username=session.get('username'),
        ))
        db.session.add(AuditLog(
            user_id=session['user_id'], username=session.get('username'),
            ip=request.remote_addr or '',
            action='passport_revoke' if p.passport.revoked else 'passport_restore',
            target=p.article, extra=p.passport.uuid,
        ))
        commit()
        flash('Статус паспорта обновлён.', 'success')
        return redirect(url_for('admin_passports'))

    @app.route('/admin/passports/<int:pid>/delete', methods=['POST'])
    @admin_required
    def admin_passport_delete(pid):
        p = db.session.get(Product, pid)
        if not p or not p.passport:
            abort(404)
        uuid_str = p.passport.uuid
        db.session.delete(p.passport)
        db.session.add(AuditLog(
            user_id=session['user_id'], username=session.get('username'),
            ip=request.remote_addr or '',
            action='passport_delete', target=p.article, extra=uuid_str,
        ))
        commit()
        flash('Паспорт удалён.', 'success')
        return redirect(url_for('admin_passports'))

    @app.route('/admin/passports/<int:pid>/qr.svg')
    @admin_required
    def admin_passport_qr(pid):
        p = db.session.get(Product, pid)
        if not p or not p.passport:
            abort(404)

        url = url_for('passport_public', uuid=p.passport.uuid, _external=True)
        img = qrcode.make(
            url,
            image_factory=qrcode.image.svg.SvgPathImage,
            box_size=10,
            border=2,
        )
        svg_data = img.to_string()
        if isinstance(svg_data, str):
            svg_data = svg_data.encode('utf-8')

        return Response(
            svg_data,
            mimetype='image/svg+xml',
            headers={
                'Cache-Control': 'no-store',
                'Content-Disposition':
                    f'inline; filename="passport-{p.article}.svg"',
            },
        )

    # ==================================================================
    # ПУБЛИЧНАЯ СТРАНИЦА ПАСПОРТА
    # ==================================================================

    @app.route('/passport/<uuid>')
    def passport_public(uuid):
        pp = ProductPassport.query.filter_by(uuid=uuid).first_or_404()
        if pp.revoked:
            return render_template('passport_revoked.html',
                                   passport=pp), 410
        return render_template('passport_public.html', passport=pp)


# ==================================================================
# ВСПОМОГАТЕЛЬНОЕ
# ==================================================================

def _cart_lines():
    rows = (db.session.query(CartItem)
            .filter_by(user_id=session['user_id'])
            .all())
    lines = []
    for ci in rows:
        p = ci.product
        lines.append({
            'product': p,
            'qty': ci.qty_m,
            'line_total': (ci.qty_m * p.price_per_m).quantize(Decimal('0.01')),
        })
    return lines