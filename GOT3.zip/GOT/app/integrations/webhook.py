"""A08-2: webhook-приёмник для внешних систем (1С, CRM, склад).

Токен — env WEBHOOK_TOKEN (≥32 символа). Аутентификация по заголовку
X-API-Token, сравнение через secrets.compare_digest. Сессионная
CSRF-защита неприменима — это машина-машина.
"""
import csv
import io
import os
import secrets
from datetime import datetime

from flask import Blueprint, Response, abort, jsonify, request
from sqlalchemy import select

from ..config import log
from ..extensions import commit, db
from ..models import AuditLog, Order, Product

TOKEN = os.environ.get('WEBHOOK_TOKEN', '').strip()
MAX_LIMIT = 200

bp = Blueprint('webhook', __name__, url_prefix='/integration/webhook')


def _auth() -> None:
    if not TOKEN or len(TOKEN) < 32:
        log.error('WEBHOOK_TOKEN не задан или короче 32 символов')
        abort(503, description='Webhook disabled')
    got = request.headers.get('X-API-Token', '')
    if not secrets.compare_digest(TOKEN, got):
        log.warning('webhook: неверный токен ip=%s path=%s',
                    request.remote_addr, request.path)
        _audit('webhook_auth_fail', request.path)
        abort(401, description='Unauthorized')


def _audit(action: str, target: str = '', extra: str = '') -> None:
    db.session.add(AuditLog(
        username='webhook-bot',
        ip=(request.remote_addr or '')[:64],
        action=action[:64],
        target=target[:120],
        extra=extra[:160],
    ))
    commit()


def _order_to_dict(o: Order) -> dict:
    return {
        'number': o.number,
        'created_at': o.created_at.isoformat(timespec='seconds'),
        'status': o.status,
        'total': f'{o.total:.2f}',
        'customer': {
            'username': o.user.username if o.user else '',
            'full_name': (o.user.full_name if o.user else '') or '',
            'email': (o.user.email if o.user else '') or '',
        },
        'items': [{
            'article': it.product.article if it.product else '',
            'name': it.product.name if it.product else '',
            'color': it.product.color if it.product else '',
            'width_mm': it.product.width_mm if it.product else 0,
            'qty_m': f'{it.qty_m:.2f}',
            'price': f'{it.price:.2f}',
            'total': f'{it.total:.2f}',
        } for it in o.items],
    }


@bp.get('/orders')
def orders_list():
    _auth()
    since_raw = request.args.get('since')
    try:
        since = datetime.fromisoformat(since_raw) if since_raw else None
    except ValueError:
        abort(400, description='since must be ISO 8601')

    status = (request.args.get('status') or '').strip()
    try:
        limit = max(1, min(int(request.args.get('limit', 50)), MAX_LIMIT))
    except (TypeError, ValueError):
        limit = 50

    stmt = select(Order).order_by(Order.id.desc()).limit(limit)
    if since:
        stmt = stmt.where(Order.created_at >= since)
    if status:
        stmt = stmt.where(Order.status == status)

    orders = db.session.scalars(stmt).all()
    _audit('webhook_orders', f'count={len(orders)}',
           f'since={since_raw} status={status}')

    fmt = (request.args.get('format') or 'json').lower()
    if fmt == 'csv':
        buf = io.StringIO()
        w = csv.writer(buf, delimiter=';')
        w.writerow(['Номер', 'Дата', 'Статус', 'Сумма',
                    'Клиент', 'Артикул', 'Наименование', 'Кол-во, м',
                    'Цена', 'Сумма позиции'])
        for o in orders:
            cust = (o.user.full_name or o.user.username) if o.user else ''
            for it in o.items:
                w.writerow([
                    o.number,
                    o.created_at.strftime('%d.%m.%Y %H:%M'),
                    o.status, f'{o.total:.2f}', cust,
                    it.product.article if it.product else '',
                    it.product.name if it.product else '',
                    f'{it.qty_m:.2f}', f'{it.price:.2f}', f'{it.total:.2f}',
                ])
        return Response('\ufeff' + buf.getvalue(),
                        mimetype='text/csv; charset=utf-8')

    return jsonify(count=len(orders),
                   orders=[_order_to_dict(o) for o in orders])


@bp.get('/orders/<number>')
def order_by_number(number: str):
    _auth()
    o = db.session.scalar(select(Order).where(Order.number == number))
    if not o:
        abort(404)
    _audit('webhook_order_one', number)
    return jsonify(_order_to_dict(o))


@bp.get('/stock')
def stock():
    _auth()
    only_low = request.args.get('low') == '1'
    stmt = select(Product).order_by(Product.article)
    if only_low:
        stmt = stmt.where(Product.stock_m < 200)
    items = db.session.scalars(stmt).all()
    _audit('webhook_stock', f'count={len(items)}', f'low={only_low}')
    return jsonify(count=len(items), items=[{
        'article': p.article,
        'name': p.name,
        'color': p.color,
        'width_mm': p.width_mm,
        'price_per_m': f'{p.price_per_m:.2f}',
        'stock_m': f'{p.stock_m:.2f}',
    } for p in items])


@bp.post('/ack')
def ack():
    _auth()
    data = request.get_json(silent=True) or {}
    ref = (data.get('ref') or '').strip()[:120]
    _audit('webhook_ack', ref)
    return jsonify(ok=True, ref=ref)


@bp.get('/health')
def health():
    return jsonify(status='ok', enabled=bool(TOKEN and len(TOKEN) >= 32))