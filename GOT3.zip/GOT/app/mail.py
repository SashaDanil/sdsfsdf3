"""Email-уведомления через SMTP.

Настройки в .env:
  SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD,
  SMTP_FROM, SMTP_TLS=1 (STARTTLS), SMTP_SSL=0 (SMTPS 465).

Без SMTP_HOST модуль выключен. Отправка через очередь notification_outbox
и фоновый worker — сбой SMTP не ломает оформление заказа.
"""
from __future__ import annotations

import os
import smtplib
import threading
from datetime import datetime
from email.message import EmailMessage

from sqlalchemy import select

from .config import log
from .extensions import commit, db, lock
from .models import NotificationOutbox

HOST = os.environ.get('SMTP_HOST', '').strip()
PORT = int(os.environ.get('SMTP_PORT', '587') or '587')
USER = os.environ.get('SMTP_USER', '').strip()
PASSWORD = os.environ.get('SMTP_PASSWORD', '').strip()
FROM = os.environ.get('SMTP_FROM', USER or 'noreply@italcozhda.local').strip()
USE_TLS = os.environ.get('SMTP_TLS', '1') == '1'
USE_SSL = os.environ.get('SMTP_SSL', '0') == '1'
POLL_INTERVAL = 5.0
MAX_ATTEMPTS = 5


def enabled() -> bool:
    return bool(HOST and FROM)


def enqueue(dedupe_key: str, recipient: str, subject: str, body: str) -> None:
    """Кладёт письмо в очередь. Желательно внутри транзакции бизнес-события."""
    if not enabled() or not recipient:
        return
    exists = db.session.scalar(
        select(NotificationOutbox).where(
            NotificationOutbox.dedupe_key == dedupe_key[:128]
        )
    )
    if exists:
        return
    db.session.add(NotificationOutbox(
        dedupe_key=dedupe_key[:128],
        recipient=recipient[:254],
        subject=subject[:200],
        body=body[:10000],
        status='pending',
        attempts=0,
    ))


def _smtp_send(to: str, subject: str, body: str) -> tuple[bool, str]:
    msg = EmailMessage()
    msg['From'] = FROM
    msg['To'] = to
    msg['Subject'] = subject
    msg.set_content(body)
    try:
        if USE_SSL:
            with smtplib.SMTP_SSL(HOST, PORT, timeout=15) as s:
                if USER:
                    s.login(USER, PASSWORD)
                s.send_message(msg)
        else:
            with smtplib.SMTP(HOST, PORT, timeout=15) as s:
                s.ehlo()
                if USE_TLS:
                    s.starttls()
                    s.ehlo()
                if USER:
                    s.login(USER, PASSWORD)
                s.send_message(msg)
        return True, ''
    except Exception as exc:  # noqa: BLE001
        return False, f'{type(exc).__name__}: {exc}'[:255]


def _drain_once() -> None:
    with lock:
        row = db.session.scalar(
            select(NotificationOutbox)
            .where(NotificationOutbox.status == 'pending')
            .order_by(NotificationOutbox.id)
            .limit(1)
        )
        if not row:
            return
        row.status = 'sending'
        commit()
        rid, to, subj, body = row.id, row.recipient, row.subject, row.body

    ok, err = _smtp_send(to, subj, body)

    with lock:
        row = db.session.get(NotificationOutbox, rid)
        if not row:
            return
        if ok:
            row.status = 'sent'
            row.sent_at = datetime.now()
            row.last_error = None
        else:
            row.attempts = int(row.attempts or 0) + 1
            row.last_error = err
            row.status = 'pending' if row.attempts < MAX_ATTEMPTS else 'failed'
        commit()
        if not ok:
            log.warning('mail: попытка %d не удалась (%s)', row.attempts, err)


def start_worker(app) -> threading.Event | None:
    if not enabled():
        log.info('Email отключён: SMTP_HOST не задан')
        return None
    stop = threading.Event()

    def _run():
        with app.app_context():
            while not stop.is_set():
                try:
                    _drain_once()
                except Exception:
                    log.exception('mail worker: ошибка')
                stop.wait(POLL_INTERVAL)

    threading.Thread(target=_run, name='mail-notify', daemon=True).start()
    log.info(
        'Email worker запущен: host=%s port=%s tls=%s ssl=%s',
        HOST, PORT, USE_TLS, USE_SSL,
    )
    return stop


# ---------- Шаблоны писем ----------

def notify_order_created(order, user) -> None:
    if not user or not getattr(user, 'email', None):
        return
    lines = [
        f'Здравствуйте, {user.full_name or user.username}!',
        '',
        f'Ваш заказ {order.number} принят.',
        f'Сумма: {order.total:.2f} ₽',
        f'Позиций: {len(order.items)}',
        '',
    ]
    for it in order.items:
        name = it.product.name if it.product else f'id={it.product_id}'
        lines.append(
            f'  • {name} — {it.qty_m} м × {it.price:.2f} = {it.total:.2f} ₽'
        )
    lines += ['', 'Мы сообщим, когда заказ будет готов к выдаче.', '', '— АИС «ИталКожДА»']
    enqueue(
        f'order:created:{order.id}',
        user.email,
        f'Заказ {order.number} принят',
        '\n'.join(lines),
    )


def notify_status_changed(order, user, status_name: str) -> None:
    if not user or not getattr(user, 'email', None):
        return
    enqueue(
        f'order:status:{order.id}:{order.status}',
        user.email,
        f'Заказ {order.number}: {status_name}',
        (
            f'Здравствуйте, {user.full_name or user.username}!\n\n'
            f'Статус вашего заказа {order.number} изменён на «{status_name}».\n'
            f'Сумма: {order.total:.2f} ₽.\n\n'
            f'— АИС «ИталКожДА»'
        ),
    )


def notify_temp_password(user, temp_password: str, expires_at) -> None:
    """Письмо с временным паролем после сброса админом."""
    if not user or not getattr(user, 'email', None):
        return
    exp = (
        expires_at.strftime('%d.%m.%Y %H:%M')
        if expires_at else 'ограниченного срока'
    )
    body = (
        f'Здравствуйте, {user.full_name or user.username}!\n\n'
        f'Администратор сбросил пароль вашей учётной записи '
        f'«{user.username}».\n\n'
        f'Временный пароль: {temp_password}\n'
        f'Действует до: {exp}\n\n'
        f'При входе система потребует задать новый пароль.\n'
        f'Никому не пересылайте это письмо.\n\n'
        f'— АИС «ИталКожДА»'
    )
    enqueue(
        f'user:temp_password:{user.id}:{int(datetime.now().timestamp())}',
        user.email,
        'Временный пароль — ИталКожДА',
        body,
    )