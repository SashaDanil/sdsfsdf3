# app/config.py
import os
import re
import logging
from pathlib import Path
from datetime import timedelta

# Логгер
log = logging.getLogger('italcozhda')
if not log.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('[%(asctime)s] %(levelname)s in %(module)s: %(message)s'))
    log.addHandler(handler)
    log.setLevel(logging.INFO)

BASE_DIR = Path(__file__).resolve().parent.parent

# --- База данных ---
DB_PATH = os.environ.get('DB_PATH', str(BASE_DIR / 'app.db'))
SQLALCHEMY_DATABASE_URI = f"sqlite:///{DB_PATH}"
SQLALCHEMY_TRACK_MODIFICATIONS = False

# --- Безопасность ---
SECRET_KEY = os.environ.get('SECRET_KEY', 'default-dev-secret-key-change-me')
SESSION_COOKIE_SECURE = os.environ.get('SESSION_COOKIE_SECURE', '0') == '1'

# Регулярные выражения
USERNAME_RE = r'^[A-Za-z0-9_.\-]{3,64}$'
FULLNAME_RE = r'^[a-zA-Zа-яА-ЯёЁ\s\-]{2,128}$'
EMAIL_RE = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'

# Пароли и блокировки
PWD_MIN_LEN = 8
PWD_MIN_CLASSES = 4
MAX = 5
MAX_FAILED_ATTEMPTS = 5
LOCKOUT_MIN = 15
TEMP_PASSWORD_TTL = timedelta(hours=24)

# Прокси
TRUSTED_PROXIES = set(os.environ.get('TRUSTED_PROXIES', '127.0.0.1').split(','))
PROXY_HOPS = int(os.environ.get('PROXY_HOPS', '1'))

# Пагинация
PRODUCTS_PER_PAGE = 12

# Статусы
STATUSES = {
    'new': 'Новый',
    'processing': 'В обработке',
    'ready': 'Готов к выдаче',
    'issued': 'Выдан',
    'cancelled': 'Отменен'
}

STATUS_BADGES = {
    'new': 'primary',
    'processing': 'info',
    'ready': 'warning',
    'issued': 'success',
    'cancelled': 'danger'
}

RETURNABLE = ('cancelled',)

# Демо-товары для seed_db.py / init_db
DEMO_PRODUCTS = [
    ('ART-001', 'Кожа искусственная "Премиум"', 'Черный', 1400, 1200.0, 500.0),
    ('ART-002', 'Кожа искусственная "Классик"', 'Бежевый', 1400, 950.0, 300.0),
    ('ART-003', 'Кожа искусственная "Эконом"', 'Красный', 1200, 600.0, 150.0),
    ('ART-004', 'Эко-кожа "Мягкая"', 'Коричневый', 1400, 1100.0, 450.0),
    ('ART-005', 'Эко-кожа "Замша"', 'Серый', 1400, 1300.0, 200.0),
    ('ART-006', 'Кожа искусственная "Глянец"', 'Синий', 1400, 1050.0, 100.0),
    ('ART-007', 'Кожа искусственная "Матовая"', 'Зеленый', 1400, 980.0, 350.0),
    ('ART-008', 'Кожа искусственная "Люкс"', 'Бордовый', 1400, 1500.0, 80.0),
    ('ART-009', 'Кожа искусственная "Стандарт"', 'Белый', 1400, 850.0, 120.0),
    ('ART-010', 'Кожа искусственная "Велюр"', 'Золотой', 1400, 1400.0, 250.0),
]

# --- Внешняя аналитика ---
YANDEX_METRIKA_ID = (os.environ.get('YANDEX_METRIKA_ID') or '').strip()
GA4_MEASUREMENT_ID = (os.environ.get('GA4_MEASUREMENT_ID') or '').strip()