# app/__init__.py
import os
from pathlib import Path
from datetime import datetime
from flask import Flask, render_template, request, session
from werkzeug.exceptions import BadRequest

from .config import (
    SECRET_KEY, SQLALCHEMY_DATABASE_URI, SQLALCHEMY_TRACK_MODIFICATIONS,
    STATUSES, STATUS_BADGES, log,
    YANDEX_METRIKA_ID, GA4_MEASUREMENT_ID,
)
from .extensions import db
from .security import validate_csrf, generate_csrf

_SENSITIVE_ENDPOINTS = {
    'admin_orders', 'admin_change_status',
    'admin_users', 'admin_user_toggle_admin', 'admin_user_delete',
    'admin_user_reset_password', 'admin_users_cleanup_probes',
    'admin_stats', 'admin_audit',
    'admin_passports', 'admin_passport_generate', 'admin_passport_revoke',
    'admin_passport_delete', 'admin_passport_qr',
    # --- нагрузочный тест БД ---
    'admin_db_health', 'admin_db_health_run',
    'admin_db_health_clear_history', 'admin_db_health_export_csv',
    # --- клиентские ---
    'orders_list', 'order_detail', 'order_qr',
    'cart_view', 'cart_add', 'cart_update', 'cart_remove',
    'cart_clear', 'cart_checkout',
    'favorites_view', 'favorites_toggle',
    'profile', 'change_password',
    'login', 'register', 'logout',
}


def color_slug(color_name):
    mapping = {
        'черный': 'black', 'чёрный': 'black', 'бежевый': 'beige', 'красный': 'red',
        'коричневый': 'brown', 'серый': 'gray', 'синий': 'blue',
        'зеленый': 'green', 'зелёный': 'green', 'бордовый': 'bordeaux',
        'белый': 'white', 'золотой': 'gold',
    }
    return mapping.get(str(color_name).lower().strip(), 'gray')


def is_fav(product_id):
    if not session.get('user_id'):
        return False
    from .models import Favorite
    return db.session.query(Favorite).filter_by(
        user_id=session['user_id'], product_id=product_id
    ).first() is not None


def create_app(config_object=None):
    _root = Path(__file__).resolve().parent.parent
    app = Flask(
        __name__,
        template_folder=str(_root / 'templates'),
        static_folder=str(_root / 'static'),
    )

    app.config['SECRET_KEY'] = SECRET_KEY
    app.config['SQLALCHEMY_DATABASE_URI'] = SQLALCHEMY_DATABASE_URI
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = SQLALCHEMY_TRACK_MODIFICATIONS

    if config_object:
        app.config.update(config_object)

    db.init_app(app)

    from . import routes
    routes.init_app(app)

    # --- нагрузочный тест БД: /admin/db-health* ---
    from .admin_health import init_admin_health
    init_admin_health(app)

    @app.before_request
    def csrf_protect():
        validate_csrf()

    @app.after_request
    def add_security_headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Content-Security-Policy'] = (
            "default-src 'self'; "
            "script-src 'self' https://cdn.jsdelivr.net "
            "https://mc.yandex.ru https://mc.yandex.com "
            "https://www.googletagmanager.com https://www.google-analytics.com; "
            "style-src 'self' https://cdn.jsdelivr.net 'unsafe-inline'; "
            "font-src 'self' https://cdn.jsdelivr.net; "
            "img-src 'self' data: https://mc.yandex.ru https://www.google-analytics.com; "
            "connect-src 'self' https://mc.yandex.ru https://mc.yandex.com "
            "https://www.google-analytics.com https://analytics.google.com "
            "https://www.googletagmanager.com; "
            "frame-src https://mc.yandex.ru; "
            "frame-ancestors 'none';"
        )

        if request.endpoint in _SENSITIVE_ENDPOINTS:
            response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
            response.headers['Pragma'] = 'no-cache'
            response.headers['Expires'] = '0'

        response.headers.pop('Server', None)
        return response

    @app.errorhandler(400)
    def handle_bad_request(e):
        return render_template('error.html', code=400, message='Неверный запрос'), 400

    @app.errorhandler(403)
    def forbidden(e):
        return render_template('error.html', code=403, message='Доступ запрещен'), 403

    @app.errorhandler(404)
    def not_found(e):
        return render_template('error.html', code=404, message='Страница не найдена'), 404

    @app.errorhandler(410)
    def gone(e):
        return render_template('error.html', code=410, message='Ресурс больше недоступен'), 410

    @app.context_processor
    def inject_globals():
        return dict(
            current_year=datetime.now().year,
            STATUSES=STATUSES,
            STATUS_BADGES=STATUS_BADGES,
            csrf_token=generate_csrf(),
            current_user_id=session.get('user_id'),
            is_admin=bool(session.get('is_admin')),
            cart_positions_count=session.get('cart_positions_count', 0),
            color_slug=color_slug,
            is_fav=is_fav,
            yandex_metrika_id=YANDEX_METRIKA_ID,
            ga4_measurement_id=GA4_MEASUREMENT_ID,
        )

    return app


def init_db(app, seed=False):
    with app.app_context():
        from . import models
        db.create_all()

        if seed:
            from .models import Product
            if not db.session.query(Product).first():
                from .config import DEMO_PRODUCTS
                for a, n, c, w, p, s in DEMO_PRODUCTS:
                    db.session.add(Product(
                        article=a, name=n, color=c, width_mm=w,
                        price_per_m=p, stock_m=s
                    ))
                db.session.commit()
                log.info('База данных инициализирована демо-товарами.')