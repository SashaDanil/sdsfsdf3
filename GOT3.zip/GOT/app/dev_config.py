"""Локальные dev-настройки. В репозиторий/прод не попадает.

PROBES — префиксы логинов, которые считаются тестовыми (созданными пентестом).
Используется в security.is_probe() и админке для очистки мусора.
"""

PROBES = (
    "pentest_",
    "csrf_",
    "idor_",
    "admin_probe_",
    "neg_",
    "cookie_",
    "rreg_",
    "race_",
    "enum_",
    "sessfix_",
    "method_probe_",
    "ratelimit_probe_",
    "csrf_all_probe_",
    "no_such_",
)