"""app/utils.py — утилиты ИталКожДА.

Содержит:
  * is_safe_redirect_url, safe_redirect — защита от open-redirect;
  * _qty, _int, _qs        — парсинг пользовательского ввода;
  * list_products, list_favorites, fav_pids — каталог и избранное;
  * orders_list_data       — данные для /orders и /admin/orders;
  * build_cart, cart_set   — работа с корзиной;
  * admins_count, purge_user, return_stock — админ-операции.
"""
from decimal import Decimal, InvalidOperation
from math import ceil
from urllib.parse import urlparse

from flask import redirect


# ---------- Безопасный redirect ----------
def is_safe_redirect_url(url: str) -> bool:
    """True только для локальных путей вида '/cart', '/orders/42'."""
    if not url or not isinstance(url, str):
        return False
    if not url.startswith('/'):
        return False
    if url.startswith('//') or url.startswith('/\\'):
        return False
    parsed = urlparse(url)
    return not parsed.scheme and not parsed.netloc


def safe_redirect(target: str, default: str = '/', code: int = 302):
    """redirect() только для локальных путей, иначе — на default."""
    return redirect(target if is_safe_redirect_url(target) else default, code=code)


# ---------- Парсинг ввода ----------
def _qty(value, default=None):
    if value is None or (isinstance(value, str) and value.strip() == ''):
        return Decimal('1')
    try:
        d = Decimal(str(value).replace(',', '.'))
    except (InvalidOperation, ValueError, TypeError):
        return default
    if d <= 0:
        return default
    return d


def _int(value, default: int = 1, lo: int = 1, hi: int | None = None) -> int:
    try:
        n = int(value)
    except (TypeError, ValueError):
        return default
    if n < lo:
        n = lo
    if hi is not None and n > hi:
        n = hi
    return n


def _qs(value, default: str = '', *, max_len: int = 200) -> str:
    if value is None:
        return default
    s = str(value).strip()
    if not s:
        return default
    return s[:max_len]


# ---------- Каталог ----------
class _ProductPage:
    """Страница каталога — совместима с несколькими стилями распаковки.

    Поддерживает:
        products, pages = list_products(...)    # tuple-unpack
        res = list_products(...); res.items     # атрибуты
        res['products'], res['pages']           # dict-доступ
    """
    __slots__ = ('items', 'page', 'pages', 'q', 'total')

    def __init__(self, items, page, pages, q, total):
        self.items = items
        self.page = page
        self.pages = pages
        self.q = q
        self.total = total

    def __iter__(self):
        # порядок: (products, pages) — самый частый вариант в шаблонах
        yield self.items
        yield self.pages

    def __getitem__(self, key):
        mapping = {
            'products': self.items,
            'items': self.items,
            'page': self.page,
            'pages': self.pages,
            'q': self.q,
            'total': self.total,
        }
        if key in mapping:
            return mapping[key]
        raise KeyError(key)

    def __len__(self):
        return len(self.items)


def list_products(q: str = '', page: int = 1, per_page: int = 12) -> _ProductPage:
    """Каталог с поиском по артикулу/названию/цвету и пагинацией."""
    from sqlalchemy import func, or_, select

    from .extensions import db
    from .models import Product

    page = _int(page, default=1, lo=1)
    per_page = _int(per_page, default=12, lo=1, hi=100)
    q = (q or '').strip()

    base = select(Product)
    if q:
        like = f'%{q}%'
        base = base.where(or_(
            Product.article.ilike(like),
            Product.name.ilike(like),
            Product.color.ilike(like),
        ))
    base = base.order_by(Product.article)

    total = db.session.scalar(
        select(func.count()).select_from(base.subquery())
    ) or 0
    pages = max(1, ceil(total / per_page))
    if page > pages:
        page = pages

    items = db.session.scalars(
        base.offset((page - 1) * per_page).limit(per_page)
    ).all()

    return _ProductPage(items, page, pages, q, total)


# ---------- Избранное ----------
def fav_pids(user_id) -> set[int]:
    """Множество id товаров в избранном у пользователя."""
    if not user_id:
        return set()
    from sqlalchemy import select

    from .extensions import db
    from .models import Favorite

    rows = db.session.scalars(
        select(Favorite.product_id).where(Favorite.user_id == user_id)
    ).all()
    return set(rows)


def list_favorites(user_id) -> list:
    """Список товаров в избранном, отсортированный по артикулу."""
    if not user_id:
        return []
    from sqlalchemy import select

    from .extensions import db
    from .models import Favorite, Product

    return db.session.scalars(
        select(Product)
        .join(Favorite, Favorite.product_id == Product.id)
        .where(Favorite.user_id == user_id)
        .order_by(Product.article)
    ).all()


# ---------- Данные для списка заказов ----------
def orders_list_data(user_id, *, is_admin: bool = False, status_filter=None):
    from sqlalchemy import func, select

    from .extensions import db
    from .models import Order, OrderItem, User

    stmt = select(Order).order_by(Order.created_at.desc())
    if is_admin:
        if status_filter:
            stmt = stmt.where(Order.status == status_filter)
    else:
        stmt = stmt.where(Order.user_id == user_id)

    rows = db.session.scalars(stmt).all()
    if not rows:
        return []

    order_ids = [o.id for o in rows]
    counts = dict(
        db.session.execute(
            select(OrderItem.order_id, func.count())
            .where(OrderItem.order_id.in_(order_ids))
            .group_by(OrderItem.order_id)
        ).all()
    )

    users_map: dict[int, str] = {}
    if is_admin:
        uids = list({o.user_id for o in rows})
        users = db.session.scalars(select(User).where(User.id.in_(uids))).all()
        users_map = {u.id: u.username for u in users}

    return [
        {
            'id': o.id,
            'number': o.number,
            'created_at': o.created_at,
            'user': users_map.get(o.user_id),
            'items_count': counts.get(o.id, 0),
            'total': o.total,
            'status': o.status,
        }
        for o in rows
    ]


# ---------- Корзина ----------
class _CartView:
    __slots__ = ('lines', 'total')

    def __init__(self, lines, total):
        self.lines = lines
        self.total = total

    @property
    def is_empty(self) -> bool:
        return not self.lines


def build_cart(user_id) -> _CartView:
    from sqlalchemy import select

    from .extensions import db
    from .models import CartItem, Product

    if not user_id:
        return _CartView([], Decimal('0'))

    rows = db.session.execute(
        select(CartItem, Product)
        .join(Product, Product.id == CartItem.product_id)
        .where(CartItem.user_id == user_id)
        .order_by(Product.article)
    ).all()

    lines = []
    total = Decimal('0')
    for ci, product in rows:
        line_total = (ci.qty_m * product.price_per_m).quantize(Decimal('0.01'))
        lines.append({
            'product': product,
            'qty': ci.qty_m,
            'line_total': line_total,
        })
        total += line_total

    return _CartView(lines, total.quantize(Decimal('0.01')))


def cart_set(user_id, product_id, qty_m) -> Decimal:
    from sqlalchemy import select

    from .extensions import db
    from .models import CartItem, Product

    if qty_m is None:
        return Decimal('0')
    try:
        qty = Decimal(qty_m)
    except (InvalidOperation, TypeError, ValueError):
        return Decimal('0')

    product = db.session.get(Product, product_id)
    if product is None:
        return Decimal('0')

    stock = product.stock_m or Decimal('0')
    if qty > stock:
        qty = stock
    if qty < 0:
        qty = Decimal('0')

    ci = db.session.get(CartItem, (user_id, product_id))
    if qty == 0:
        if ci is not None:
            db.session.delete(ci)
        return Decimal('0')

    if ci is None:
        ci = CartItem(user_id=user_id, product_id=product_id, qty_m=qty)
        db.session.add(ci)
    else:
        ci.qty_m = qty
    return qty


# ---------- Админ-операции ----------
def admins_count() -> int:
    from sqlalchemy import func, select

    from .extensions import db
    from .models import User

    return db.session.scalar(
        select(func.count()).select_from(User).where(User.is_admin.is_(True))
    ) or 0


def return_stock(order) -> None:
    if order is None:
        return
    for item in getattr(order, 'items', ()):
        product = getattr(item, 'product', None)
        if product is None or not item.qty_m:
            continue
        product.stock_m = (product.stock_m or Decimal('0')) + item.qty_m


def purge_user(user, name=None) -> int:
    """Удалить пользователя и связанные данные.

    Возвращает число удалённых заказов (для сводки в админке).
    Второй аргумент `name` — для обратной совместимости с call-sites,
    в самой функции не используется.
    """
    from sqlalchemy import delete, select

    from .extensions import db
    from .models import CartItem, Favorite, Order, OrderItem, User

    uid = user.id if hasattr(user, 'id') else int(user)
    u = db.session.get(User, uid)
    if u is None:
        return 0

    order_ids = db.session.scalars(
        select(Order.id).where(Order.user_id == uid)
    ).all()
    no = len(order_ids)
    if order_ids:
        db.session.execute(
            delete(OrderItem).where(OrderItem.order_id.in_(order_ids))
        )
        db.session.execute(delete(Order).where(Order.user_id == uid))

    db.session.execute(delete(CartItem).where(CartItem.user_id == uid))
    db.session.execute(delete(Favorite).where(Favorite.user_id == uid))
    db.session.delete(u)
    return no