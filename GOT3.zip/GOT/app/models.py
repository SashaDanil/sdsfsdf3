"""Модели БД АИС «ИталКожДА»."""
from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from .extensions import db


class User(db.Model):
    __tablename__ = 'user'

    id          = db.Column(db.Integer, primary_key=True)
    username    = db.Column(db.String(64), unique=True, nullable=False, index=True)
    full_name   = db.Column(db.String(128))
    email       = db.Column(db.String(128))
    password_hash = db.Column(db.String(255), nullable=False)
    is_admin    = db.Column(db.Boolean, default=False, nullable=False)
    created_at  = db.Column(db.DateTime, default=datetime.now)

    session_version = db.Column(db.Integer, default=1, nullable=False)
    must_change_password = db.Column(db.Boolean, default=False, nullable=False)
    temp_password_expires_at = db.Column(db.DateTime)

    @property
    def is_probe(self) -> bool:
        from .security import is_probe
        return is_probe(self.username)

    def __repr__(self) -> str:
        return f'<User {self.username}>'


class Product(db.Model):
    __tablename__ = 'product'

    id          = db.Column(db.Integer, primary_key=True)
    article     = db.Column(db.String(64), unique=True, nullable=False, index=True)
    name        = db.Column(db.String(128), nullable=False)
    color       = db.Column(db.String(64), nullable=False)
    width_mm    = db.Column(db.Integer, nullable=False)
    price_per_m = db.Column(db.Numeric(10, 2), nullable=False)
    stock_m     = db.Column(db.Numeric(10, 2), nullable=False, default=Decimal('0'))

    def __repr__(self) -> str:
        return f'<Product {self.article} {self.name}>'


class Order(db.Model):
    __tablename__ = 'order'

    id          = db.Column(db.Integer, primary_key=True)
    number      = db.Column(db.String(64), unique=True, nullable=False, index=True)
    user_id     = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    total       = db.Column(db.Numeric(12, 2), nullable=False, default=Decimal('0'))
    status      = db.Column(db.String(32), nullable=False, default='new')
    created_at  = db.Column(db.DateTime, default=datetime.now, nullable=False)

    user  = db.relationship('User', backref='orders')
    items = db.relationship('OrderItem', backref='order',
                            cascade='all, delete-orphan')

    @property
    def items_count(self) -> int:
        return len(self.items)

    @property
    def items_summary(self) -> str:
        if not self.items:
            return '—'
        first = self.items[0]
        p = first.product
        rest = len(self.items) - 1
        label = f'{p.name} ({p.color})'
        if rest:
            label += f' и ещё {rest}'
        return label


class OrderItem(db.Model):
    __tablename__ = 'order_item'

    id         = db.Column(db.Integer, primary_key=True)
    order_id   = db.Column(db.Integer, db.ForeignKey('order.id', ondelete='CASCADE'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    qty_m      = db.Column(db.Numeric(10, 2), nullable=False)
    price      = db.Column(db.Numeric(10, 2), nullable=False)
    total      = db.Column(db.Numeric(12, 2), nullable=False)

    product = db.relationship('Product')


class CartItem(db.Model):
    __tablename__ = 'cart_item'

    user_id    = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'), primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id', ondelete='CASCADE'), primary_key=True)
    qty_m      = db.Column(db.Numeric(10, 2), nullable=False)

    product = db.relationship('Product')


class Favorite(db.Model):
    __tablename__ = 'favorite'

    user_id    = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'), primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id', ondelete='CASCADE'), primary_key=True)
    created_at = db.Column(db.DateTime, default=datetime.now)


class AuditLog(db.Model):
    __tablename__ = 'audit_log'

    id       = db.Column(db.Integer, primary_key=True)
    ts       = db.Column(db.DateTime, default=datetime.now, nullable=False, index=True)
    user_id  = db.Column(db.Integer, db.ForeignKey('user.id'))
    username = db.Column(db.String(64))
    ip       = db.Column(db.String(64))
    action   = db.Column(db.String(64), nullable=False, index=True)
    target   = db.Column(db.String(128))
    extra    = db.Column(db.Text)


class LoginAttempt(db.Model):
    __tablename__ = 'login_attempt'

    id         = db.Column(db.Integer, primary_key=True)
    username   = db.Column(db.String(64), nullable=False, index=True)
    ip         = db.Column(db.String(64), nullable=False)
    success    = db.Column(db.Boolean, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False, index=True)


class RegisterAttempt(db.Model):
    __tablename__ = 'register_attempt'

    id         = db.Column(db.Integer, primary_key=True)
    ip         = db.Column(db.String(64), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False, index=True)


# ---------------------------------------------------------------------------
# Цифровые паспорта продукта (DPP)
# ---------------------------------------------------------------------------

class ProductPassport(db.Model):
    """Цифровой паспорт товара: UUID + история событий."""

    __tablename__ = 'product_passport'

    id          = db.Column(db.Integer, primary_key=True)
    product_id  = db.Column(
        db.Integer,
        db.ForeignKey('product.id', ondelete='CASCADE'),
        nullable=False,
        unique=True,
    )
    uuid        = db.Column(db.String(36), unique=True,
                            nullable=False, index=True)
    issued_at   = db.Column(db.DateTime, default=datetime.now, nullable=False)
    issued_by   = db.Column(db.Integer, db.ForeignKey('user.id'))
    public_note = db.Column(db.String(500))
    revoked     = db.Column(db.Boolean, default=False, nullable=False)

    product = db.relationship(
        'Product',
        backref=db.backref('passport', uselist=False,
                           cascade='all, delete-orphan'),
    )
    issuer = db.relationship('User', foreign_keys=[issued_by])
    events = db.relationship(
        'PassportEvent',
        backref='passport',
        cascade='all, delete-orphan',
        order_by='PassportEvent.ts.desc()',
    )

    def __repr__(self) -> str:
        return f'<ProductPassport product={self.product_id} uuid={self.uuid[:8]}…>'


class PassportEvent(db.Model):
    """Append-only журнал событий паспорта."""

    __tablename__ = 'passport_event'

    id          = db.Column(db.Integer, primary_key=True)
    passport_id = db.Column(
        db.Integer,
        db.ForeignKey('product_passport.id', ondelete='CASCADE'),
        nullable=False,
        index=True,
    )
    event_type  = db.Column(db.String(32), nullable=False)
    ts          = db.Column(db.DateTime, default=datetime.now, nullable=False)
    username    = db.Column(db.String(64))
    metadata_   = db.Column(db.Text)

    def __repr__(self) -> str:
        return f'<PassportEvent {self.event_type} at {self.ts:%Y-%m-%d %H:%M}>'


class NotificationOutbox(db.Model):
    """Очередь email-уведомлений."""

    __tablename__ = 'notification_outbox'

    id         = db.Column(db.Integer, primary_key=True)
    dedupe_key = db.Column(db.String(128), nullable=False, unique=True, index=True)
    recipient  = db.Column(db.String(254), nullable=False)
    subject    = db.Column(db.String(200), nullable=False)
    body       = db.Column(db.Text, nullable=False)
    status     = db.Column(db.String(16), nullable=False, default='pending', index=True)
    attempts   = db.Column(db.Integer, nullable=False, default=0)
    last_error = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False, index=True)
    sent_at    = db.Column(db.DateTime)


class DBHealthRun(db.Model):
    """История нагрузочных тестов БД (админка /admin/db-health)."""

    __tablename__ = 'db_health_run'

    id          = db.Column(db.Integer, primary_key=True)
    ts          = db.Column(db.DateTime, default=datetime.now,
                            nullable=False, index=True)
    username    = db.Column(db.String(64))
    preset      = db.Column(db.String(64), nullable=False)
    iterations  = db.Column(db.Integer, nullable=False)
    concurrency = db.Column(db.Integer, nullable=False)
    elapsed_s   = db.Column(db.Float)
    avg_ms      = db.Column(db.Float)
    p50_ms      = db.Column(db.Float)
    p95_ms      = db.Column(db.Float)
    p99_ms      = db.Column(db.Float)
    min_ms      = db.Column(db.Float)
    max_ms      = db.Column(db.Float)
    throughput  = db.Column(db.Float)