import ipaddress
import os
import sys
from pathlib import Path

# ---------- Автозагрузка .env ДО импорта app ----------
BASE_DIR = Path(__file__).resolve().parent
try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / '.env', override=False)
except ImportError:
    pass

from app import create_app, init_db
from app.config import PROXY_HOPS, TRUSTED_PROXIES, log

app = create_app()

# ---------- 1. Фикс путей к templates/ и static/ ----------
_templates_dir = BASE_DIR / 'templates'
_static_dir = BASE_DIR / 'static'
if _templates_dir.is_dir():
    app.template_folder = str(_templates_dir)
    app.__dict__.pop('jinja_env', None)
if _static_dir.is_dir():
    app.static_folder = str(_static_dir)

# ---------- 2. Фикс NOT NULL constraint failed: audit_log.extra ----------
from sqlalchemy import event as _sa_event
from app.models import AuditLog as _AuditLog


@_sa_event.listens_for(_AuditLog, 'before_insert')
def _coerce_audit_strings(mapper, connection, target):
    """Заменить None → '' в NOT NULL строковых полях AuditLog."""
    for field in ('username', 'ip', 'action', 'target', 'extra'):
        if getattr(target, field, None) is None:
            setattr(target, field, '')


_LOOPBACK_NAMES = frozenset({'localhost', 'localhost.localdomain'})


def _is_loopback(host: str) -> bool:
    if not host:
        return False
    h = host.strip().strip('[]').lower()
    if h in _LOOPBACK_NAMES:
        return True
    try:
        return ipaddress.ip_address(h).is_loopback
    except ValueError:
        return False


def _resolve_debug(host: str, debug_env: str, allow_debug_env: str) -> bool:
    want_debug = debug_env == '1'
    allow_debug = allow_debug_env == '1'

    if not want_debug:
        return False

    if not allow_debug:
        log.warning('DEBUG=1 проигнорирован: ALLOW_DEBUG не установлен в 1.')
        print('[!] DEBUG=1 проигнорирован: установите ALLOW_DEBUG=1 для включения.')
        return False

    if not _is_loopback(host):
        log.warning('DEBUG=1 проигнорирован: host=%s не loopback.', host)
        print(f'[!] DEBUG=1 проигнорирован: host={host} не loopback.')
        return False

    return True


if __name__ == '__main__':
    host = os.environ.get('HOST', '127.0.0.1')
    try:
        port = int(os.environ.get('PORT', '5000'))
    except ValueError:
        print('[!] PORT должен быть числом.')
        sys.exit(2)

    debug = _resolve_debug(
        host,
        os.environ.get('DEBUG', '0'),
        os.environ.get('ALLOW_DEBUG', '0'),
    )

    wait = os.environ.get('USE_WAITRESS', '1') == '1' and not debug
    seed = os.environ.get('SEED_DB', '0') == '1'

    init_db(app, seed=seed)

    try:
        from app.mail import start_worker
        start_worker(app)
    except Exception as _mail_exc:
        print(f"[!] mail worker: {_mail_exc}")

    log.info(
        'Старт: host=%s port=%s debug=%s waitress=%s trusted_proxies=%s hops=%s',
        host, port, debug, wait, sorted(TRUSTED_PROXIES), PROXY_HOPS,
    )
    print(f'[OK] http://{host}:{port} (debug={debug}, waitress={wait})')

    if wait:
        try:
            from waitress import serve

            serve_kwargs = dict(
                host=host,
                port=port,
                threads=8,
                ident='',
                clear_untrusted_proxy_headers=True,
            )

            trusted_proxy = next(iter(TRUSTED_PROXIES), None)
            if trusted_proxy:
                serve_kwargs.update(
                    trusted_proxy=trusted_proxy,
                    trusted_proxy_count=PROXY_HOPS,
                    trusted_proxy_headers={'x-forwarded-for', 'x-forwarded-proto'},
                )
            serve(app, **serve_kwargs)
        except ImportError:
            print('[!] waitress не установлен — Flask dev-сервер')
            app.run(host=host, port=port, debug=False, threaded=True)
    else:
        app.run(host=host, port=port, debug=debug, threaded=True)