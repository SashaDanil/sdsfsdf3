# tests/test_audit.py
def test_login_creates_audit_record(client, user, app):
    from tests.conftest import _login
    from app.models import AuditLog
    _login(client, user)
    with app.app_context():
        assert AuditLog.query.filter_by(action='login',
                                        username=user['username']).count() == 1