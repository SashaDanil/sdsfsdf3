# tests/test_admin.py
from tests.conftest import _csrf


def test_admin_orders_requires_admin(user_client):
    r = user_client.get('/admin/orders')
    assert r.status_code == 403


def test_admin_stats_ok(admin_client):
    r = admin_client.get('/admin/stats')
    assert r.status_code == 200


def test_admin_change_status_and_return_stock(admin_client, user_client, user, app):
    from app.extensions import db
    from app.models import Order, Product
    from decimal import Decimal
    # создаём заказ
    t = _csrf(user_client, '/')
    user_client.post('/cart/add/1', data={'_csrf_token': t, 'qty_m': '5'})
    t = _csrf(user_client, '/')
    user_client.post('/cart/checkout', data={'_csrf_token': t})
    with app.app_context():
        o = Order.query.first(); oid = o.id
    # отменяем через админа
    t = _csrf(admin_client, '/admin/orders')
    admin_client.post(f'/admin/orders/{oid}/status',
                      data={'_csrf_token': t, 'status': 'cancelled'})
    with app.app_context():
        assert db.session.get(Order, oid).status == 'cancelled'
        assert db.session.get(Product, 1).stock_m == Decimal('100')  # вернулся


def test_admin_cannot_remove_last_admin(admin_client, admin, app):
    """Нельзя снять/удалить последнего админа."""
    from tests.conftest import _csrf
    t = _csrf(admin_client, '/admin/users')
    r = admin_client.post(f'/admin/users/{admin["id"]}/toggle_admin',
                          data={'_csrf_token': t}, follow_redirects=True)
    # самого себя нельзя вообще
    assert 'себя'.encode() in r.data


def test_admin_reset_password_sets_flag(admin_client, user, app):
    from app.extensions import db
    from app.models import User
    from tests.conftest import _csrf
    t = _csrf(admin_client, '/admin/users')
    admin_client.post(f'/admin/users/{user["id"]}/reset_password',
                      data={'_csrf_token': t})
    with app.app_context():
        u = db.session.get(User, user['id'])
        assert u.must_change_password is True
        assert u.temp_password_expires_at is not None