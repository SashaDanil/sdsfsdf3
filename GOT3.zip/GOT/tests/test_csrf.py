# tests/test_csrf.py
def test_post_without_csrf_400(client, user):
    # без токена
    r = client.post('/login', data={'username': 'x', 'password': 'y'})
    assert r.status_code == 400


def test_post_with_bad_csrf_400(client):
    r = client.post('/login', data={'_csrf_token': 'deadbeef',
                                    'username': 'x', 'password': 'y'})
    assert r.status_code == 400


def test_json_content_type_rejected(client, user):
    r = client.post('/login', data='{}', content_type='application/json')
    assert r.status_code == 400


def test_csrf_fail_is_audited(client, app):
    client.post('/login', data={'_csrf_token': 'x', 'username': 'a', 'password': 'b'})
    from app.models import AuditLog
    with app.app_context():
        assert app.extensions['sqlalchemy'].session.query(AuditLog)\
            .filter_by(action='csrf_fail').count() >= 1