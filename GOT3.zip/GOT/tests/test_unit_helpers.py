# tests/test_unit_helpers.py
import pytest
from decimal import Decimal
from app.security import pwd_ok, valid_email, is_probe
from app.utils import is_safe_redirect_url, _qty, _int


@pytest.mark.parametrize('pwd,ok', [
    ('short', False), ('12345678', False), ('qwertyui', False),
    ('Password1!', True), ('abcDEF123', False), ('aB3!xxxx', True),
])
def test_pwd_ok(pwd, ok):
    assert pwd_ok(pwd)[0] is ok


@pytest.mark.parametrize('email,ok', [
    ('a@b.ru', True), ('bad@', False), ('x@y.z', True),
    ('a b@c.ru', False), ('', False),
])
def test_valid_email(email, ok):
    assert valid_email(email) is ok


def test_is_probe():
    assert is_probe('pentest_1')
    assert is_probe('csrf_abc')
    assert not is_probe('alice')


@pytest.mark.parametrize('url,ok', [
    ('/cart', True), ('//evil.com', False), ('http://evil.com', False),
    ('https://evil.com', False), ('javascript:alert(1)', False),
    ('', False),
])
def test_safe_redirect(url, ok):
    assert is_safe_redirect_url(url) is ok


def test_qty_parsing():
    assert _qty('1.5') == Decimal('1.5')
    assert _qty('abc') is None
    assert _qty('') == Decimal('1')


def test_int_clamp():
    assert _int('0') == 1
    assert _int('99999', hi=10) == 10
    assert _int('abc', default=5) == 5