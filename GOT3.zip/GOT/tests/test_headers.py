# tests/test_headers.py
import re
from pathlib import Path

import pytest

from app import _SENSITIVE_ENDPOINTS


def test_security_headers(client):
    r = client.get('/login')
    h = r.headers
    assert h['X-Content-Type-Options'] == 'nosniff'
    assert h['X-Frame-Options'] == 'DENY'
    assert "script-src 'self' https://cdn.jsdelivr.net" in h['Content-Security-Policy']
    assert "frame-ancestors 'none'" in h['Content-Security-Policy']
    assert 'Server' not in h


def test_no_store_on_sensitive(client):
    r = client.get('/login')
    assert 'no-store' in r.headers['Cache-Control']


# ---------- A02-1: no-store на всех чувствительных страницах ----------
@pytest.mark.parametrize('path', [
    '/login', '/register', '/profile',
    '/orders', '/cart', '/favorites',
    '/admin/orders', '/admin/users', '/admin/stats', '/admin/audit',
])
def test_no_store_covers_sensitive(client, user_client, admin_client, path):
    c = admin_client if path.startswith('/admin/') else user_client
    r = c.get(path, follow_redirects=True)
    assert 'no-store' in r.headers.get('Cache-Control', ''), path
    assert r.headers.get('Pragma') == 'no-cache', path
    assert r.headers.get('Expires') == '0', path


def test_all_admin_views_in_sensitive_set():
    expected = {
        'admin_orders', 'admin_change_status',
        'admin_users', 'admin_user_toggle_admin', 'admin_user_delete',
        'admin_user_reset_password', 'admin_users_cleanup_probes',
        'admin_stats', 'admin_audit',
    }
    assert expected <= _SENSITIVE_ENDPOINTS


def test_all_private_client_views_in_sensitive_set():
    expected = {
        'orders_list', 'order_detail',
        'cart_view', 'cart_add', 'cart_update', 'cart_remove',
        'cart_clear', 'cart_checkout',
        'favorites_view', 'favorites_toggle',
    }
    assert expected <= _SENSITIVE_ENDPOINTS


# ---------- A02-2: никаких inline on*= в шаблонах ----------
_INLINE_HANDLER_RE = re.compile(r'\son[a-z]+\s*=', re.IGNORECASE)
_TEMPLATES_DIR = Path(__file__).resolve().parent.parent / 'templates'


def test_no_inline_event_handlers_in_templates():
    """CSP script-src без 'unsafe-inline' молча блокирует inline on*=.
    Хуже всего это для onsubmit="return confirm(...)" в админке: confirm
    не появляется, форма отправляется сразу (destructive action без
    подтверждения). Держим инвариант на уровне файлов шаблонов."""
    assert _TEMPLATES_DIR.is_dir(), f'нет каталога {_TEMPLATES_DIR}'
    offenders = []
    for f in sorted(_TEMPLATES_DIR.glob('*.html')):
        for i, line in enumerate(f.read_text(encoding='utf-8').splitlines(), 1):
            if _INLINE_HANDLER_RE.search(line):
                offenders.append(f'{f.name}:{i}: {line.strip()}')
    assert not offenders, (
        "Найдены inline-обработчики (несовместимо с CSP script-src "
        "'self' без 'unsafe-inline'). Используйте data-* и обработчик "
        "в static/app.js:\n" + '\n'.join(offenders)
    )