# tests/test_passports.py
from tests.conftest import _csrf


def _generate(admin_client, pid=1):
    t = _csrf(admin_client, '/admin/passports')
    return admin_client.post(
        f'/admin/passports/{pid}/generate',
        data={'_csrf_token': t},
        follow_redirects=True,
    )


def test_admin_passports_requires_admin(user_client):
    assert user_client.get('/admin/passports').status_code == 403


def test_admin_passports_page_ok(admin_client):
    r = admin_client.get('/admin/passports')
    assert r.status_code == 200
    assert 'Цифровые паспорта'.encode() in r.data


def test_generate_creates_passport_and_event(admin_client, app):
    from app.models import ProductPassport, PassportEvent
    _generate(admin_client)
    with app.app_context():
        pp = ProductPassport.query.first()
        assert pp is not None
        assert pp.revoked is False
        assert PassportEvent.query.filter_by(passport_id=pp.id).count() == 1


def test_generate_is_idempotent(admin_client, app):
    from app.models import ProductPassport
    _generate(admin_client)
    _generate(admin_client)
    with app.app_context():
        assert ProductPassport.query.count() == 1


def test_public_passport_visible_without_login(client, admin_client, app):
    from app.models import ProductPassport
    _generate(admin_client)
    with app.app_context():
        uuid = ProductPassport.query.first().uuid
    r = client.get(f'/passport/{uuid}')
    assert r.status_code == 200
    assert 'Цифровой паспорт'.encode() in r.data


def test_unknown_uuid_returns_404(client):
    assert client.get('/passport/does-not-exist').status_code == 404


def test_revoked_passport_returns_410(client, admin_client, app):
    from app.models import ProductPassport
    _generate(admin_client)
    with app.app_context():
        pp = ProductPassport.query.first()
        uuid, pid = pp.uuid, pp.product_id

    t = _csrf(admin_client, '/admin/passports')
    admin_client.post(
        f'/admin/passports/{pid}/revoke',
        data={'_csrf_token': t},
    )

    r = client.get(f'/passport/{uuid}')
    assert r.status_code == 410


def test_qr_returns_svg(admin_client, app):
    _generate(admin_client)
    r = admin_client.get('/admin/passports/1/qr.svg')
    assert r.status_code == 200
    assert 'image/svg+xml' in r.headers['Content-Type']
    assert b'<svg' in r.data


def test_delete_passport(admin_client, app):
    from app.models import ProductPassport
    _generate(admin_client)
    t = _csrf(admin_client, '/admin/passports')
    admin_client.post(
        '/admin/passports/1/delete',
        data={'_csrf_token': t},
        follow_redirects=True,
    )
    with app.app_context():
        assert ProductPassport.query.count() == 0


def test_passports_in_sensitive_endpoints():
    from app import _SENSITIVE_ENDPOINTS
    expected = {
        'admin_passports',
        'admin_passport_generate',
        'admin_passport_revoke',
        'admin_passport_delete',
        'admin_passport_qr',
    }
    assert expected <= _SENSITIVE_ENDPOINTS