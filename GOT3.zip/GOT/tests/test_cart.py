# tests/test_cart.py
from decimal import Decimal
from app.extensions import db
from app.models import Product, CartItem, Order, OrderItem
from tests.conftest import _csrf


def test_cart_add_respects_stock(user_client, app):
    t = _csrf(user_client, '/')
    user_client.post('/cart/add/1', data={'_csrf_token': t, 'qty_m': '9999'})
    with app.app_context():
        ci = db.session.get(CartItem, (1, 1))
        assert ci.qty_m <= Decimal('100')  # max stock


def test_cart_negative_qty_rejected(user_client):
    t = _csrf(user_client, '/')
    r = user_client.post('/cart/add/1', data={'_csrf_token': t, 'qty_m': '-5'},
                         follow_redirects=True)
    assert 'Некорректное'.encode() in r.data


def test_checkout_creates_order_and_decrements_stock(user_client, user, app):
    t = _csrf(user_client, '/')
    user_client.post('/cart/add/1', data={'_csrf_token': t, 'qty_m': '3'})
    t = _csrf(user_client, '/')
    user_client.post('/cart/checkout', data={'_csrf_token': t})
    with app.app_context():
        o = Order.query.filter_by(user_id=user['id']).first()
        assert o and o.status == 'new'
        assert OrderItem.query.filter_by(order_id=o.id).count() == 1
        p = db.session.get(Product, 1)
        assert p.stock_m == Decimal('97')


def test_checkout_empty_cart(user_client):
    t = _csrf(user_client, '/')
    r = user_client.post('/cart/checkout', data={'_csrf_token': t},
                         follow_redirects=True)
    assert 'пуста'.encode() in r.data


def test_cart_clear(user_client, app):
    t = _csrf(user_client, '/')
    user_client.post('/cart/add/1', data={'_csrf_token': t, 'qty_m': '1'})
    t = _csrf(user_client, '/')
    user_client.post('/cart/clear', data={'_csrf_token': t})
    with app.app_context():
        assert CartItem.query.count() == 0