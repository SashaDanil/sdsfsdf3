# pip install psycopg2-binary
import os
import time
import statistics
from concurrent.futures import ThreadPoolExecutor
import psycopg2

DB_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "port": int(os.getenv("DB_PORT", 5432)),
    "dbname": os.getenv("DB_NAME", "postgres"),
    "user": os.getenv("DB_USER", "postgres"),
    "password": os.getenv("DB_PASSWORD", "postgres"),
    "connect_timeout": 5,
}

# Запрос, отклик которого проверяем
QUERY = "SELECT 1;"

ITERATIONS = 1000          # всего запросов
CONCURRENCY = 10           # параллельных клиентов
WARMUP_PER_WORKER = 10     # прогрев на каждого клиента


def worker(worker_id, iterations):
    conn = psycopg2.connect(**DB_CONFIG)
    conn.autocommit = True
    latencies = []

    try:
        with conn.cursor() as cur:
            # Прогрев
            for _ in range(WARMUP_PER_WORKER):
                cur.execute(QUERY)
                cur.fetchall()

            # Замер
            for _ in range(iterations):
                t0 = time.perf_counter()
                cur.execute(QUERY)
                cur.fetchall()
                latencies.append((time.perf_counter() - t0) * 1000)  # мс
    finally:
        conn.close()

    return latencies


def percentile(values, p):
    if not values:
        return 0.0
    values = sorted(values)
    k = (len(values) - 1) * p
    f = int(k)
    c = min(f + 1, len(values) - 1)
    if f == c:
        return values[f]
    return values[f] + (values[c] - values[f]) * (k - f)


def main():
    per_worker = max(1, ITERATIONS // CONCURRENCY)

    start_all = time.perf_counter()
    with ThreadPoolExecutor(max_workers=CONCURRENCY) as ex:
        chunks = list(
            ex.map(lambda i: worker(i, per_worker), range(CONCURRENCY))
        )
    elapsed = time.perf_counter() - start_all

    latencies = [x for chunk in chunks for x in chunk]

    if not latencies:
        print("Нет данных")
        return

    print(f"Запрос: {QUERY}")
    print(f"Всего запросов: {len(latencies)}")
    print(f"Параллельных клиентов: {CONCURRENCY}")
    print(f"Общее время: {elapsed:.2f} с")
    print("-" * 40)
    print(f"Средний отклик: {statistics.mean(latencies):.2f} мс")
    print(f"Медиана p50:   {percentile(latencies, 0.50):.2f} мс")
    print(f"p95:           {percentile(latencies, 0.95):.2f} мс")
    print(f"p99:           {percentile(latencies, 0.99):.2f} мс")
    print(f"Минимум:       {min(latencies):.2f} мс")
    print(f"Максимум:      {max(latencies):.2f} мс")
    print(f"Пропускная способность: {len(latencies) / elapsed:.2f} зап/с")


if __name__ == "__main__":
    main()