import os
import pytest
from decimal import Decimal
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

os.environ.setdefault('SECRET_KEY', 'test-secret-key-with-lots-of-unique-chars-0123456789ABCDEF')
os.environ.setdefault('SESSION_COOKIE_SECURE', '0')   # test client работает по HTTP

from app import create_app
from app.extensions import db as _db
from app.models import Product, User
from werkzeug.security import generate_password_hash


@pytest.fixture
def app(tmp_path, monkeypatch):
    monkeypatch.setenv('DB_PATH', str(tmp_path / 'test.db'))
    # переимпорт config, чтобы DATABASE_URI подхватил DB_PATH
    import importlib, app.config as cfg
    importlib.reload(cfg)

    flask_app = create_app()
    flask_app.config.update(TESTING=True, WTF_CSRF_ENABLED=False)
    with flask_app.app_context():
        _db.create_all()
        # минимальный демо-склад
        _db.session.add(Product(article='T-001', name='Тест', color='Чёрный',
                                width_mm=1400, price_per_m=Decimal('1000'),
                                stock_m=Decimal('100')))
        _db.session.commit()
        yield flask_app
        _db.session.remove()
        _db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def user(app):
    with app.app_context():
        u = User(username='alice', full_name='Alice A.',
                 password_hash=generate_password_hash('Pa55word!', method='scrypt'))
        _db.session.add(u); _db.session.commit()
        return {'id': u.id, 'username': u.username, 'password': 'Pa55word!'}


@pytest.fixture
def admin(app):
    with app.app_context():
        u = User(username='root', full_name='Root',
                 password_hash=generate_password_hash('Pa55word!', method='scrypt'),
                 is_admin=True)
        _db.session.add(u); _db.session.commit()
        return {'id': u.id, 'username': u.username, 'password': 'Pa55word!'}


def _csrf(client, path='/login'):
    """Возвращает CSRF-токен из сессии (после GET)."""
    client.get(path)
    with client.session_transaction() as s:
        return s.get('_csrf')


def _login(client, u, path='/login'):
    token = _csrf(client, path)
    return client.post(path, data={
        'username': u['username'], 'password': u['password'],
        '_csrf_token': token,
    }, follow_redirects=True)


@pytest.fixture
def user_client(client, user):
    _login(client, user)
    return client


@pytest.fixture
def admin_client(client, admin):
    _login(client, admin)
    return client