# tests/test_auth.py
from app.extensions import db
from app.models import User, LoginAttempt
from tests.conftest import _csrf, _login
from werkzeug.security import generate_password_hash, check_password_hash


def test_register_ok(client):
    t = _csrf(client, '/register')
    r = client.post('/register', data={
        'username': 'bob', 'password': 'Pa55word!',
        'full_name': 'Bob B.', 'email': 'bob@b.ru',
        '_csrf_token': t,
    }, follow_redirects=True)
    assert r.status_code == 200
    with client.application.app_context():
        assert db.session.scalar(db.select(User).where(User.username == 'bob'))


def test_register_weak_password(client):
    t = _csrf(client, '/register')
    r = client.post('/register', data={
        'username': 'weak', 'password': '123',
        '_csrf_token': t,
    }, follow_redirects=True)
    assert b'\xd0\xbc\xd0\xb8\xd0\xbd\xd0\xb8\xd0\xbc\xd1\x83\xd0\xbc' in r.data  # «минимум»


def test_register_duplicate(client, user):
    t = _csrf(client, '/register')
    r = client.post('/register', data={
        'username': user['username'], 'password': 'Pa55word!',
        '_csrf_token': t,
    }, follow_redirects=True)
    assert 'занят'.encode() in r.data


def test_login_ok(client, user):
    r = _login(client, user)
    assert r.status_code == 200
    with client.session_transaction() as s:
        assert s['user_id'] == user['id']


def test_login_wrong_password(client, user):
    t = _csrf(client)
    r = client.post('/login', data={
        'username': user['username'], 'password': 'wrong',
        '_csrf_token': t,
    })
    assert 'Неверный'.encode() in r.data


def test_login_lockout(client, user, app):
    # 5 неуспешных попыток
    for _ in range(5):
        t = _csrf(client)
        client.post('/login', data={
            'username': user['username'], 'password': 'wrong',
            '_csrf_token': t,
        })
    # 6-я — заблокирована даже с верным паролем
    t = _csrf(client)
    r = client.post('/login', data={
        'username': user['username'], 'password': user['password'],
        '_csrf_token': t,
    })
    assert 'Слишком много попыток'.encode() in r.data


def test_session_version_invalidation(client, user, app):
    _login(client, user)
    # админ/скрипт увеличивает session_version
    with app.app_context():
        u = db.session.get(User, user['id'])
        u.session_version += 1
        db.session.commit()
    r = client.get('/', follow_redirects=True)
    assert 'устарела'.encode() in r.data


def test_temp_password_expired(client, user, app):
    with app.app_context():
        u = db.session.get(User, user['id'])
        u.must_change_password = True
        from datetime import datetime, timedelta
        u.temp_password_expires_at = datetime.now() - timedelta(hours=1)
        db.session.commit()
    t = _csrf(client)
    r = client.post('/login', data={
        'username': user['username'], 'password': user['password'],
        '_csrf_token': t,
    })
    assert 'истёк'.encode() in r.data.lower()


def test_must_change_password_redirects(user_client):
    # пользователь с флагом must_change_password не уходит с /profile
    # (см. отдельный тест: создаём отдельный user)
    pass