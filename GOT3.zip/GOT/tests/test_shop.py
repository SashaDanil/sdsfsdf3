# tests/test_shop.py
def test_index_requires_login(client):
    r = client.get('/', follow_redirects=False)
    assert r.status_code == 302 and '/login' in r.headers['Location']


def test_products_search(user_client):
    r = user_client.get('/products?q=тест')
    assert r.status_code == 200


def test_products_csv_export(user_client):
    r = user_client.get('/products/export.csv')
    assert r.status_code == 200
    assert r.mimetype.startswith('text/csv')
    assert '\ufeff'.encode('utf-8') in r.data   # BOM


def test_favorites_toggle(user_client, user, app):
    from app.models import Favorite
    from tests.conftest import _csrf
    t = _csrf(user_client, '/')
    r = user_client.post('/favorites/toggle/1', data={'_csrf_token': t},
                         follow_redirects=True)
    assert r.status_code == 200
    with app.app_context():
        assert Favorite.query.filter_by(user_id=user['id'], product_id=1).first()
    # повторный toggle → удаление
    t = _csrf(user_client, '/')
    user_client.post('/favorites/toggle/1', data={'_csrf_token': t})
    with app.app_context():
        assert not Favorite.query.filter_by(user_id=user['id'], product_id=1).first()