# tests/test_orders.py
def test_order_detail_idor(user_client, app):
    """Пользователь A не должен видеть заказ пользователя B."""
    from app.models import User, Order
    from werkzeug.security import generate_password_hash
    from app.extensions import db
    with app.app_context():
        other = User(username='bob', password_hash=generate_password_hash(
            'Pa55word!', method='scrypt'))
        db.session.add(other); db.session.commit()
        o = Order(number='X', user_id=other.id, total=0, status='new')
        db.session.add(o); db.session.commit()
        oid = o.id
    r = user_client.get(f'/orders/{oid}')
    assert r.status_code == 404