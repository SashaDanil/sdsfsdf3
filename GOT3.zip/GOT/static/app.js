/* static/app.js — ИталКожДА
 * Обработчики без инлайн-скриптов (совместимо с CSP script-src 'self' + CDN).
 */
(function () {
  'use strict';

  // --- Копирование временного пароля ---
  var copyBtn = document.getElementById('copy-temp-pwd');
  if (copyBtn) {
    copyBtn.addEventListener('click', function () {
      var el = document.getElementById('temp-pwd');
      if (!el) return;
      var text = el.textContent || '';

      function done() {
        var old = copyBtn.innerHTML;
        copyBtn.innerHTML = '<i class="bi bi-check2"></i> Скопировано';
        setTimeout(function () { copyBtn.innerHTML = old; }, 1500);
      }

      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(done).catch(fallback);
      } else {
        fallback();
      }

      function fallback() {
        var r = document.createRange();
        r.selectNodeContents(el);
        var s = window.getSelection();
        s.removeAllRanges();
        s.addRange(r);
        try { document.execCommand('copy'); done(); } catch (e) {}
        s.removeAllRanges();
      }
    });
  }

  // --- A02-2: делегированный confirm через data-confirm ---
  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form || form.tagName !== 'FORM') return;
    var msg = form.getAttribute('data-confirm');
    if (!msg) return;
    if (!window.confirm(msg)) {
      e.preventDefault();
      e.stopPropagation();
    }
  }, true);

  // --- Копирование произвольного текста из data-copy-text ---
  document.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-copy-text]');
    if (!btn) return;

    var text = btn.getAttribute('data-copy-text') || '';
    if (!text) return;

    var old = btn.innerHTML;

    function done() {
      btn.innerHTML = '<i class="bi bi-check2"></i>';
      setTimeout(function () { btn.innerHTML = old; }, 1500);
    }

    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand('copy'); done(); } catch (err) {}
      document.body.removeChild(ta);
    }

    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(done).catch(fallback);
    } else {
      fallback();
    }
  });

  // --- График выручки на /admin/stats ---
  var canvas = document.getElementById('dailyChart');
  if (canvas && typeof window.Chart !== 'undefined') {
    var labels = [];
    var values = [];
    try {
      labels = JSON.parse(canvas.getAttribute('data-labels') || '[]');
      values = JSON.parse(canvas.getAttribute('data-values') || '[]');
    } catch (e) {
      labels = [];
      values = [];
    }
    if (labels.length) {
      new Chart(canvas, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [{
            label: 'Выручка, ₽',
            data: values,
            borderColor: '#0d6efd',
            backgroundColor: 'rgba(13, 110, 253, 0.15)',
            fill: true,
            tension: 0.3,
            pointRadius: 3
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: { y: { beginAtZero: true } }
        }
      });
    }
  }
    // --- Нагрузочный тест БД (admin/db-health) ---
  var healthForm = document.querySelector('[data-db-health-form]');
  if (healthForm) {
    healthForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var url       = healthForm.getAttribute('data-url');
      var btn       = healthForm.querySelector('button[type="submit"]');
      var resultBox = document.getElementById('db-health-result');
      if (!url || !btn || !resultBox) return;

      var oldBtn = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Выполняется…';
      resultBox.innerHTML = '<div class="alert alert-info mb-0">' +
        '<span class="spinner-border spinner-border-sm me-2"></span>' +
        'Нагружаем БД…</div>';

      var fd = new FormData(healthForm);

      fetch(url, { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(function (r) {
          return r.json().then(function (data) {
            return { ok: r.ok, status: r.status, data: data };
          });
        })
        .then(function (res) {
          if (!res.ok) {
            resultBox.innerHTML = '<div class="alert alert-danger mb-0">' +
              'Ошибка ' + res.status + ': ' +
              escapeHtml((res.data && res.data.error) || 'неизвестно') +
              '</div>';
            return;
          }
          resultBox.innerHTML = renderHealthResult(res.data);
          // Перезагрузим страницу, чтобы обновилась история.
          setTimeout(function () { window.location.reload(); }, 1200);
        })
        .catch(function (err) {
          resultBox.innerHTML = '<div class="alert alert-danger mb-0">' +
            'Сеть: ' + escapeHtml(String(err)) + '</div>';
        })
        .finally(function () {
          btn.disabled = false;
          btn.innerHTML = oldBtn;
        });
    });

    function escapeHtml(s) {
      return String(s).replace(/[&<>"']/g, function (c) {
        return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;',
                  '"': '&quot;', "'": '&#39;' })[c];
      });
    }

    function renderHealthResult(d) {
      return '<div class="alert alert-success mb-0">' +
        '<h6 class="mb-2"><i class="bi bi-check2-circle me-1"></i>' +
        escapeHtml(d.preset_label) + '</h6>' +
        '<div class="row g-2 small">' +
          '<div class="col-md-3"><b>Средний:</b> ' + d.avg_ms + ' мс</div>' +
          '<div class="col-md-3"><b>p50:</b> ' + d.p50_ms + ' мс</div>' +
          '<div class="col-md-3"><b>p95:</b> ' + d.p95_ms + ' мс</div>' +
          '<div class="col-md-3"><b>p99:</b> ' + d.p99_ms + ' мс</div>' +
          '<div class="col-md-3"><b>Min/Max:</b> ' + d.min_ms + ' / ' + d.max_ms + ' мс</div>' +
          '<div class="col-md-3"><b>Запросов:</b> ' + d.iterations + '</div>' +
          '<div class="col-md-3"><b>Потоков:</b> ' + d.concurrency + '</div>' +
          '<div class="col-md-3"><b>Пропускная:</b> ' + d.throughput + ' зап/с</div>' +
          '<div class="col-md-12"><b>Время:</b> ' + d.elapsed_s + ' с</div>' +
        '</div>' +
      '</div>';
    }
  }
})();