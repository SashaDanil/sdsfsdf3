"""Назначение администратора по логину.

Запуск:
    python make_admin.py Sasha_Godsize
"""
import sys
from sqlalchemy import select

from app import create_app
from app.extensions import db, commit
from app.models import User


def make_admin(username: str) -> int:
    app = create_app()
    with app.app_context():
        u = db.session.scalar(select(User).where(User.username == username))
        if not u:
            print(f"[!] Пользователь '{username}' не найден.")
            print("    Сначала зарегистрируйте его через /register.")
            return 1

        if u.is_admin:
            print(f"[=] '{username}' уже администратор. Ничего не меняю.")
            return 0

        u.is_admin = True
        # Важно: сбрасываем активные сессии пользователя
        u.session_version = int(u.session_version or 1) + 1
        commit()

        print(f"[+] Пользователь '{username}' (id={u.id}) назначен администратором.")
        print("    Теперь войдите заново под этим логином — появятся кнопки админки.")
        return 0


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("Использование: python make_admin.py <логин>")
        sys.exit(2)
    sys.exit(make_admin(sys.argv[1]))