"""Полное наполнение БД демо-данными для АИС «ИталКожДА».

Запуск:
    python seed_db.py              # наполнить (идемпотентно: пропустит, если уже есть данные)
    python seed_db.py --reset      # удалить app.db и создать заново
    python seed_db.py --force      # наполнить поверх существующих данных

Создаёт:
  * 10 товаров из DEMO_PRODUCTS;
  * администратора admin / Admin123!;
  * 5 пользователей (alice, bob, carol, dave, erin) с паролем User1234!;
  * избранное, корзины;
  * ~25 заказов за 14 дней во всех статусах;
  * записи аудита и попытки входа.
"""
from __future__ import annotations

import argparse
import os
import random
import secrets
import sys
from datetime import datetime, timedelta
from decimal import Decimal
from pathlib import Path

# --- Окружение до импорта app ---
ROOT = Path(__file__).resolve().parent

# 1) Сначала подхватываем .env (там обычно лежит «настоящий» SECRET_KEY).
#    load_dotenv по умолчанию НЕ перезаписывает уже заданные env-переменные,
#    поэтому порядок важен: сначала .env, потом setdefault.
try:
    from dotenv import load_dotenv
    load_dotenv(ROOT / '.env', override=False)
except ImportError:
    pass

# 2) Если SECRET_KEY всё ещё не задан — генерируем случайный (48 байт ≈ 64 символа).
#    Каждый запуск seed_db.py будет новым ключом — это нормально: скрипт
#    не работает с сессиями, а БД-данные от ключа не зависят.
os.environ.setdefault('SECRET_KEY', secrets.token_urlsafe(48))

os.environ.setdefault('SESSION_COOKIE_SECURE', '0')
os.environ.setdefault('DB_PATH', str(ROOT / 'app.db'))
os.environ.setdefault('SEED_DB', '0')  # мы наполняем вручную

from sqlalchemy import delete, func, select  # noqa: E402
from werkzeug.security import generate_password_hash  # noqa: E402

from app import create_app, init_db  # noqa: E402
from app.config import DEMO_PRODUCTS, STATUSES  # noqa: E402
from app.extensions import commit, db, immediate_transaction  # noqa: E402
from app.models import (  # noqa: E402
    AuditLog, CartItem, Favorite, LoginAttempt, Order, OrderItem,
    Product, RegisterAttempt, User,
)

# ---------- Параметры ----------
ADMIN_LOGIN = 'admin'
ADMIN_PASSWORD = 'Admin123!'
USER_PASSWORD = 'User1234!'

USERS = [
    # (логин, ФИО, email)
    ('alice',  'Алиса Иванова',     'alice@example.com'),
    ('bob',    'Борис Петров',      'bob@example.com'),
    ('carol',  'Каролина Сидорова', 'carol@example.com'),
    ('dave',   'Давид Кузнецов',    'dave@example.com'),
    ('erin',   'Эрин Смирнова',     'erin@example.com'),
]

# Вероятности статусов для генерации заказов
STATUS_WEIGHTS = [
    ('new',        0.20),
    ('processing', 0.20),
    ('ready',      0.15),
    ('issued',     0.35),
    ('cancelled',  0.10),
]

RNG = random.Random(20241014)  # детерминированно — удобно для тестов


# ---------- Хелперы ----------
def _pick_status() -> str:
    r = RNG.random()
    acc = 0.0
    for code, w in STATUS_WEIGHTS:
        acc += w
        if r <= acc:
            return code
    return 'issued'


def _order_number(dt: datetime, seq: int) -> str:
    # Уникальный номер: З-YYYYMMDDHHMMSSmmm-XX
    return f"З-{dt.strftime('%Y%m%d%H%M%S')}{seq:02d}"


def _mk_user(login: str, full_name: str, email: str, is_admin: bool = False) -> User:
    return User(
        username=login,
        full_name=full_name,
        email=email,
        is_admin=is_admin,
        password_hash=generate_password_hash(
            ADMIN_PASSWORD if is_admin else USER_PASSWORD, method='scrypt'),
        session_version=1,
        must_change_password=False,
        temp_password_expires_at=None,
        created_at=datetime.now() - timedelta(days=RNG.randint(20, 120)),
    )


def _ensure_products() -> list[Product]:
    existing = db.session.scalars(select(Product).order_by(Product.article)).all()
    if existing:
        print(f'[=] Товары уже есть: {len(existing)} шт.')
        return existing

    products = []
    for a, n, c, w, p, s in DEMO_PRODUCTS:
        products.append(Product(
            article=a, name=n, color=c, width_mm=w,
            price_per_m=Decimal(p), stock_m=Decimal(s),
        ))
    db.session.add_all(products)
    commit()
    print(f'[+] Добавлено товаров: {len(products)}')
    return products


def _ensure_users() -> dict[str, User]:
    users: dict[str, User] = {}

    # Админ
    admin = db.session.scalar(select(User).where(User.username == ADMIN_LOGIN))
    if not admin:
        admin = _mk_user(ADMIN_LOGIN, 'Администратор Системы',
                         'admin@italcozhda.local', is_admin=True)
        db.session.add(admin)
        commit()
        print(f'[+] Создан админ: {ADMIN_LOGIN} / {ADMIN_PASSWORD}')
    else:
        print(f'[=] Админ {ADMIN_LOGIN} уже есть')
    users[ADMIN_LOGIN] = admin

    # Обычные пользователи
    for login, full_name, email in USERS:
        u = db.session.scalar(select(User).where(User.username == login))
        if not u:
            u = _mk_user(login, full_name, email)
            db.session.add(u)
            commit()
            print(f'[+] Создан пользователь: {login} / {USER_PASSWORD}')
        else:
            print(f'[=] Пользователь {login} уже есть')
        users[login] = u

    return users


def _seed_favorites(users: dict[str, User], products: list[Product]) -> None:
    if db.session.scalar(select(func.count()).select_from(Favorite)):
        print('[=] Избранное уже заполнено')
        return
    n = 0
    for login in ('alice', 'bob', 'carol', 'dave', 'erin'):
        u = users[login]
        for p in RNG.sample(products, k=RNG.randint(1, 4)):
            db.session.add(Favorite(user_id=u.id, product_id=p.id))
            n += 1
    commit()
    print(f'[+] Избранное: {n} записей')


def _seed_carts(users: dict[str, User], products: list[Product]) -> None:
    if db.session.scalar(select(func.count()).select_from(CartItem)):
        print('[=] Корзины уже заполнены')
        return
    n = 0
    for login in ('alice', 'bob', 'carol'):
        u = users[login]
        for p in RNG.sample(products, k=RNG.randint(1, 3)):
            qty = Decimal(str(RNG.choice([1, 1.5, 2, 3, 5, 10])))
            if qty > p.stock_m:
                qty = p.stock_m
            if qty <= 0:
                continue
            db.session.add(CartItem(user_id=u.id, product_id=p.id, qty_m=qty))
            n += 1
    commit()
    print(f'[+] Корзины: {n} позиций')


def _seed_orders(users: dict[str, User], products: list[Product]) -> None:
    if db.session.scalar(select(func.count()).select_from(Order)):
        print('[=] Заказы уже есть')
        return

    # Ограничим пользователей, у которых будут заказы (без админа)
    buyers = [users[l] for l, _, _ in USERS]
    now = datetime.now()
    total_orders = 0
    total_items = 0
    seq = 0

    # 25 заказов за последние 14 дней (для красивого графика)
    for _ in range(25):
        u = RNG.choice(buyers)
        # Случайная дата за последние 14 дней
        dt = now - timedelta(
            days=RNG.randint(0, 13),
            hours=RNG.randint(0, 23),
            minutes=RNG.randint(0, 59),
        )
        status = _pick_status()
        seq += 1

        # 1–3 позиции
        chosen = RNG.sample(products, k=RNG.randint(1, 3))
        total = Decimal('0')
        items: list[OrderItem] = []

        order = Order(
            number=_order_number(dt, seq),
            user_id=u.id,
            total=Decimal('0'),
            status=status,
            created_at=dt,
        )
        db.session.add(order)
        db.session.flush()  # нужен order.id

        for p in chosen:
            qty = Decimal(str(RNG.choice([1, 2, 3, 5, 8, 12, 20])))
            if qty > p.stock_m:
                qty = max(Decimal('1'), p.stock_m)
            price = p.price_per_m
            line_total = (qty * price).quantize(Decimal('0.01'))
            items.append(OrderItem(
                order_id=order.id, product_id=p.id,
                qty_m=qty, price=price, total=line_total,
            ))
            total += line_total

            # Списание со склада только для не-отменённых
            if status != 'cancelled':
                p.stock_m = max(Decimal('0'), p.stock_m - qty)

        order.total = total.quantize(Decimal('0.01'))
        db.session.add_all(items)
        total_orders += 1
        total_items += len(items)

    commit()
    print(f'[+] Заказы: {total_orders}, позиций: {total_items}')


def _seed_audit(users: dict[str, User]) -> None:
    if db.session.scalar(select(func.count()).select_from(AuditLog)):
        print('[=] Аудит уже заполнен')
        return
    now = datetime.now()
    n = 0
    for login, u in users.items():
        # регистрация
        db.session.add(AuditLog(
            ts=u.created_at, user_id=u.id, username=login,
            ip=f'192.168.1.{RNG.randint(2, 250)}',
            action='register', target=login, extra='',
        ))
        n += 1
        # несколько входов
        for _ in range(RNG.randint(1, 5)):
            db.session.add(AuditLog(
                ts=now - timedelta(days=RNG.randint(0, 14),
                                  hours=RNG.randint(0, 23)),
                user_id=u.id, username=login,
                ip=f'192.168.1.{RNG.randint(2, 250)}',
                action='login', target=login, extra='',
            ))
            n += 1
    commit()
    print(f'[+] Аудит: {n} записей')


def _seed_login_attempts(users: dict[str, User]) -> None:
    if db.session.scalar(select(func.count()).select_from(LoginAttempt)):
        print('[=] LoginAttempt уже заполнены')
        return
    now = datetime.now()
    n = 0
    for login in users:
        # успешные
        for _ in range(RNG.randint(1, 4)):
            db.session.add(LoginAttempt(
                username=login, ip=f'192.168.1.{RNG.randint(2, 250)}',
                success=True,
                created_at=now - timedelta(days=RNG.randint(0, 14),
                                           hours=RNG.randint(0, 23)),
            ))
            n += 1
        # пара неудачных (но не больше MAX_FAILED, чтобы не блокировать)
        for _ in range(RNG.randint(0, 2)):
            db.session.add(LoginAttempt(
                username=login, ip=f'10.0.0.{RNG.randint(2, 250)}',
                success=False,
                created_at=now - timedelta(days=RNG.randint(0, 14),
                                           hours=RNG.randint(0, 23)),
            ))
            n += 1
    commit()
    print(f'[+] LoginAttempt: {n} записей')


def _seed_register_attempts() -> None:
    if db.session.scalar(select(func.count()).select_from(RegisterAttempt)):
        print('[=] RegisterAttempt уже заполнены')
        return
    now = datetime.now()
    for _ in range(3):
        db.session.add(RegisterAttempt(
            ip=f'203.0.113.{RNG.randint(2, 250)}',
            created_at=now - timedelta(hours=RNG.randint(1, 48)),
        ))
    commit()
    print('[+] RegisterAttempt: 3 записи')


def _wipe(app) -> None:
    """Полная очистка всех таблиц (кроме схемы)."""
    with app.app_context():
        # порядок важен из-за FK
        for model in (OrderItem, Order, CartItem, Favorite,
                      LoginAttempt, RegisterAttempt, AuditLog,
                      Product, User):
            db.session.execute(delete(model))
        commit()
        print('[!] Все таблицы очищены')


def _reset_db_file() -> None:
    db_path = Path(os.environ['DB_PATH'])
    for suffix in ('', '-wal', '-shm'):
        p = Path(str(db_path) + suffix)
        if p.exists():
            p.unlink()
            print(f'[!] Удалён {p}')


# ---------- Main ----------
def main() -> int:
    parser = argparse.ArgumentParser(description='Наполнение БД демо-данными')
    parser.add_argument('--reset', action='store_true',
                        help='удалить файл БД и создать заново')
    parser.add_argument('--force', action='store_true',
                        help='наполнить поверх существующих данных')
    args = parser.parse_args()

    if args.reset:
        _reset_db_file()

    app = create_app()
    init_db(app, seed=True)  # создаст таблицы и 10 товаров, если пусто

    if args.force:
        _wipe(app)

    with app.app_context():
        print('\n=== Наполнение БД ===')
        products = _ensure_products()
        users = _ensure_users()
        _seed_favorites(users, products)
        _seed_carts(users, products)
        _seed_orders(users, products)
        _seed_audit(users)
        _seed_login_attempts(users)
        _seed_register_attempts()

        # Итоговая статистика
        print('\n=== Итог ===')
        for label, model in (
            ('Товаров', Product),
            ('Пользователей', User),
            ('  из них админов', None),
            ('Заказов', Order),
            ('Позиций заказов', OrderItem),
            ('Избранного', Favorite),
            ('Корзин', CartItem),
            ('Аудит', AuditLog),
            ('LoginAttempt', LoginAttempt),
            ('RegisterAttempt', RegisterAttempt),
        ):
            if model is None:
                n = db.session.scalar(
                    select(func.count()).select_from(User)
                    .where(User.is_admin.is_(True))) or 0
            else:
                n = db.session.scalar(
                    select(func.count()).select_from(model)) or 0
            print(f'  {label:>20}: {n}')

        rev = db.session.scalar(
            select(func.sum(Order.total))
            .where(Order.status.in_(('processing', 'ready', 'issued')))) or Decimal(0)
        print(f'\n  Выручка (без отменённых): {rev:.2f} ₽')

    print('\n[OK] Готово.')
    print(f'     Админ:   {ADMIN_LOGIN} / {ADMIN_PASSWORD}')
    print(f'     Клиент:  alice / {USER_PASSWORD}')
    return 0


if __name__ == '__main__':
    sys.exit(main())